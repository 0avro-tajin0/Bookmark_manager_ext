// ── Localization (i18n) ──────────────────────────────────────────────
// Loaded before newtab.js / popup.js. Exposes a global `I18N` object.
//
// UI language is SEPARATE from S.locale (which controls date/time/temperature
// formatting derived from timezone). Language is chosen by browser language,
// with an optional manual override persisted in localStorage under `mz-lang`
// (values: 'auto' | 'en' | 'ru'). localStorage is shared across the extension
// origin, so the popup and the new-tab page stay in sync.
(function () {
  'use strict';

  const SUPPORTED = ['en', 'ru'];
  const LANG_KEY = 'mz-lang';

  function detectLang() {
    const nav = (navigator.languages && navigator.languages[0]) || navigator.language || 'en';
    return String(nav).toLowerCase().startsWith('ru') ? 'ru' : 'en';
  }

  function resolveLang() {
    let override;
    try { override = localStorage.getItem(LANG_KEY); } catch (e) {}
    if (SUPPORTED.includes(override)) return override;
    return detectLang();
  }

  const lang = resolveLang();

  // Russian plural: n → [one, few, many]
  // 1 книга / 2 книги / 5 книг
  function plRu(n, one, few, many) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
    return many;
  }
  function plEn(n, one, many) { return n === 1 ? one : many; }

  // ── Strings ──
  // Values are strings (with {name} placeholders) or functions (params) => string.
  const STR = {
    en: {
      // sidebar / chrome
      'fab.newBoard': '+ New board',
      'side.search': 'Search',
      'side.widgets': 'Widgets',
      'side.import': 'Import',
      'side.importTitle': 'Import bookmarks',
      'side.export': 'Export',
      'side.exportTitle': 'Export bookmarks',
      'side.wallpaper': 'Wallpaper',
      'side.trash': 'Trash',
      'side.menu': 'Menu',
      'side.settings': 'Settings',
      'side.searchTitle': 'Search (Ctrl+K)',
      // search
      'search.placeholder': 'Search bookmarks…',
      'search.widgetPlaceholder': 'Search…',
      'search.noResults': 'No results',
      'search.defaultEngine': 'Default browser',
      // import modal
      'import.header': 'Import from Chrome Bookmarks',
      'import.loading': 'Loading…',
      'import.noFolders': 'No bookmark folders found.',
      'import.failed': 'Could not load bookmarks.',
      'import.action': 'Import',
      'import.untitled': 'Untitled',
      'import.bookmarksMeta': (p) => `${p.n} bookmark${p.n !== 1 ? 's' : ''}`,
      'import.selectAll': 'Select all',
      'import.selectedCount': (p) => `${p.n} selected`,
      'import.importSelected': 'Import selected',
      'import.importSelectedN': (p) => `Import selected (${p.n})`,
      'import.actionSingle': 'Import just this folder',
      'sync.badgeTitle': 'Synced with a Chrome bookmarks folder',
      // trash
      'trash.title': 'Trash',
      'trash.emptyConfirm': 'Empty trash?',
      'trash.deleteAll': 'Delete all',
      'trash.empty': 'Empty trash',
      'trash.isEmpty': 'Trash is empty',
      'trash.restore': 'Restore',
      'trash.boardMeta': (p) => `Board · ${p.n} link${p.n !== 1 ? 's' : ''}`,
      // wallpaper
      // widgets gallery
      'widgets.label': 'Widgets',
      'widget.board': 'Board',
      'widget.notes': 'Notes',
      'widget.pomodoro': 'Pomodoro',
      'widget.clock': 'Clock',
      'widget.search': 'Search',
      'widget.add': 'Add',
      // style editor
      // board / bookmarks
      'board.new': 'New Board',
      'board.more': (p) => `+${p.n} more`,
      'board.showLess': 'Show less',
      'notes.placeholder': 'Write anything...',
      // weather popup
      // focus stats
      'focus.today': 'Focus today',
      'focus.stats': 'Focus statistics',
      'focus.week': 'This week',
      'focus.months': 'By months',
      'focus.none': 'No focus sessions yet',
      // pomodoro
      'pom.focus': 'Focus',
      'pom.short': 'Short Break',
      'pom.long': 'Long Break',
      'pom.title': 'Pomodoro',
      'pom.focusMin': 'Focus (min)',
      'pom.shortMin': 'Short break (min)',
      'pom.longMin': 'Long break (min)',
      'pom.longAfter': 'Long break after',
      // add-link popup
      'addlink.pasteUrl': 'Paste URL…',
      'addlink.name': 'Name',
      'addlink.descOptional': 'Description (optional)',
      'addlink.add': 'Add Link',
      // tooltips
      'tip.newPage': 'New page',
      'tip.addLink': 'Add link',
      'tip.skip': 'Skip',
      'tip.reset': 'Reset',
      'tip.deletePermanently': 'Delete permanently',
      // context menus
      'menu.open': 'Open',
      'menu.openIncognito': 'Open in incognito',
      'menu.edit': 'Edit',
      'menu.delete': 'Delete',
      'menu.rename': 'Rename',
      'menu.openAll': 'Open all links',
      'menu.deleteBoard': 'Delete board',
      // onboarding
      'onboard.title': 'Welcome to BlackCodex Bookmark Manager',
      'onboard.sub': 'Your new tab, organized.',
      'onboard.start': 'Get started',
      'common.cancel': 'Cancel',
      'common.close': 'Close',
      'common.reset': 'Reset',
      'common.save': 'Save',
      'common.normal': 'Normal',
      'common.bold': 'Bold',
      // settings
      'settings.title': 'Settings',
      'st.data': 'Data',
      'st.download': 'Download data',
      'st.appearance': 'Appearance',
      'st.primaryColor': 'Primary color',
      'st.boardColor': 'Board color',
      'st.opacity': 'Opacity',
      'st.blur': 'Blur',
      'st.boardText': 'Board text',
      'st.boards': 'Boards',
      'st.size': 'Size',
      'st.weight': 'Weight',
      'st.general': 'General',
      'st.openNewTab': 'Open links in new tab',
      'st.boardColumns': 'Number of columns',
      'st.boardWidth': 'Board width',
      'st.colsAuto': 'Auto',
      'st.colsHint': (p) => `Your screen fits up to ${p.n} ${plEn(p.n, 'column', 'columns')}.`,
      'st.hideExtra': 'Hide extra bookmarks',
      'st.showN': (p) => `Show ${p.n}`,
      'st.showDescriptions': 'Show descriptions',
      'st.quickSave': 'Quick Save',
      'st.saveToPage': 'Save to page',
      'st.saveToBoard': 'Save to board',
      'st.shortcut': 'Shortcut',
      'st.notSet': 'Not set',
      'st.change': 'Change',
      'st.language': 'Language',
      'st.langAuto': 'Auto',
      'st.region': 'Region',
      'st.autoDetect': 'Auto-detect',
      'st.advancedOpen': 'Advanced ›',
      'st.advancedClose': 'Advanced ‹',
      'st.timeFormat': 'Time format',
      'st.dateFormat': 'Date format',
      'st.weekStart': 'Week starts on',
      'st.monday': 'Monday',
      'st.sunday': 'Sunday',
      'st.sidebar': 'Sidebar',
      'st.alwaysShow': 'Always show all buttons',
      'st.support': 'Support',
      'st.version': 'Version',
      // limit hints
      // tour
      'tour.skip': 'Skip tour',
      'tour.next': 'Next →',
      'tour.done': 'Done',
      'tour.importBookmarks': 'Import bookmarks',
      'tour.maybeLater': 'Maybe later',
      'tour.counter': (p) => `${p.i} of ${p.total}`,
      'tour.boardsTitle': 'Your boards',
      'tour.boardsDesc': 'Each board holds your bookmarks. Organize them however makes sense for you.',
      'tour.addTitle': 'Add a bookmark',
      'tour.addDesc': 'Click the + button on any board to save a link.',
      'tour.pagesTitle': 'Organize with pages',
      'tour.pagesDesc': 'Create pages for Work, Personal, Travel, or whatever makes sense for you.',
      'tour.menuTitle': 'Explore the menu',
      'tour.menuDesc': 'Change your wallpaper, add widgets, or import your Chrome bookmarks.',
      'tour.settingsTitle': 'Settings',
      'tour.settingsDesc': 'Account, board layout, and everything in between, all in one place.',
      'tour.saveTitle': 'Save any page in a click',
      'tour.saveDesc': 'Click the BlackCodex Bookmark Manager icon in the toolbar to save the current tab. You can also set up a keyboard shortcut in Settings.',
      'tour.bringTitle': 'Bring in your bookmarks',
      'tour.bringDesc': "Let's import your existing Chrome bookmarks into boards. It only takes a click.",
      'tour.dragTitle': 'Drag to organize',
      'tour.dragDesc': 'Drag any bookmark to move it between boards, or reorder it within a board.',
      'tour.doneTitle': "You're all set!",
      'tour.doneDesc': "That's all you need to know. Go ahead and make it yours.",
      // calendar / stats arrays
      'cal.dayShort': ['Su','Mo','Tu','We','Th','Fr','Sa'],
      'cal.monShort': ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      'clock.days': ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
      // popup (Quick Save)
      'popup.quickSave': 'Quick Save',
      'popup.saveTo': 'Save to BlackCodex Bookmark Manager',
      'popup.url': 'URL',
      'popup.title': 'Title',
      'popup.titlePlaceholder': 'Page title',
      'popup.page': 'Page',
      'popup.board': 'Board',
      'popup.save': 'Save bookmark',
      'popup.saved': 'Saved!',
      'popup.urlRequired': 'URL is required.',
      'popup.noData': 'No data found.',
      'popup.noBoards': 'No boards found.',
      'popup.loadFail': 'Could not load data.',
    },
    ru: {
      'fab.newBoard': '+ Новая доска',
      'side.search': 'Поиск',
      'side.widgets': 'Виджеты',
      'side.import': 'Импорт',
      'side.importTitle': 'Импорт закладок',
      'side.export': 'Экспорт',
      'side.exportTitle': 'Экспорт закладок',
      'side.wallpaper': 'Обои',
      'side.trash': 'Корзина',
      'side.menu': 'Меню',
      'side.settings': 'Настройки',
      'side.searchTitle': 'Поиск (Ctrl+K)',
      'search.placeholder': 'Поиск по закладкам…',
      'search.widgetPlaceholder': 'Поиск…',
      'search.noResults': 'Ничего не найдено',
      'search.defaultEngine': 'Поиск по умолчанию',
      'import.header': 'Импорт из закладок Chrome',
      'import.loading': 'Загрузка…',
      'import.noFolders': 'Папки с закладками не найдены.',
      'import.failed': 'Не удалось загрузить закладки.',
      'import.action': 'Импорт',
      'import.untitled': 'Без названия',
      'import.bookmarksMeta': (p) => `${p.n} ${plRu(p.n, 'закладка', 'закладки', 'закладок')}`,
      'import.selectAll': 'Выбрать все',
      'import.selectedCount': (p) => `Выбрано: ${p.n}`,
      'import.importSelected': 'Импортировать выбранное',
      'import.importSelectedN': (p) => `Импортировать выбранное (${p.n})`,
      'import.actionSingle': 'Импортировать только эту папку',
      'sync.badgeTitle': 'Синхронизировано с папкой закладок Chrome',
      'trash.title': 'Корзина',
      'trash.emptyConfirm': 'Очистить корзину?',
      'trash.deleteAll': 'Удалить всё',
      'trash.empty': 'Очистить корзину',
      'trash.isEmpty': 'Корзина пуста',
      'trash.restore': 'Восстановить',
      'trash.boardMeta': (p) => `Доска · ${p.n} ${plRu(p.n, 'ссылка', 'ссылки', 'ссылок')}`,
      'widgets.label': 'Виджеты',
      'widget.board': 'Доска',
      'widget.notes': 'Заметки',
      'widget.pomodoro': 'Помодоро',
      'widget.clock': 'Часы',
      'widget.search': 'Поиск',
      'widget.add': 'Добавить',
      'board.new': 'Новая доска',
      'board.more': (p) => `Ещё ${p.n}`,
      'board.showLess': 'Свернуть',
      'notes.placeholder': 'Пишите что угодно…',
      'focus.today': 'Фокус',
      'focus.stats': 'Статистика фокуса',
      'focus.week': 'Эта неделя',
      'focus.months': 'По месяцам',
      'focus.none': 'Пока нет ни одной сессии',
      'pom.focus': 'Фокус',
      'pom.short': 'Перерыв',
      'pom.long': 'Отдых',
      'pom.title': 'Помодоро',
      'pom.focusMin': 'Фокус (мин)',
      'pom.shortMin': 'Короткий перерыв (мин)',
      'pom.longMin': 'Длинный перерыв (мин)',
      'pom.longAfter': 'Длинный перерыв каждые',
      'addlink.pasteUrl': 'Вставьте ссылку…',
      'addlink.name': 'Название',
      'addlink.descOptional': 'Описание (необязательно)',
      'addlink.add': 'Добавить ссылку',
      'tip.newPage': 'Новая страница',
      'tip.addLink': 'Добавить ссылку',
      'tip.skip': 'Пропустить',
      'tip.reset': 'Сбросить',
      'tip.deletePermanently': 'Удалить навсегда',
      'menu.open': 'Открыть',
      'menu.openIncognito': 'Открыть в инкогнито',
      'menu.edit': 'Изменить',
      'menu.delete': 'Удалить',
      'menu.rename': 'Переименовать',
      'menu.openAll': 'Открыть все ссылки',
      'menu.deleteBoard': 'Удалить доску',
      'onboard.title': 'Добро пожаловать в BlackCodex Bookmark Manager',
      'onboard.sub': 'Новая вкладка, где всё под рукой.',
      'onboard.start': 'Начать',
      'common.cancel': 'Отмена',
      'common.close': 'Закрыть',
      'common.reset': 'Сбросить',
      'common.save': 'Сохранить',
      'common.normal': 'Обычный',
      'common.bold': 'Жирный',
      'settings.title': 'Настройки',
      'st.data': 'Данные',
      'st.download': 'Скачать данные',
      'st.appearance': 'Внешний вид',
      'st.primaryColor': 'Основной цвет',
      'st.boardColor': 'Цвет доски',
      'st.opacity': 'Прозрачность',
      'st.blur': 'Размытие',
      'st.boardText': 'Текст доски',
      'st.boards': 'Доски',
      'st.size': 'Размер',
      'st.weight': 'Толщина',
      'st.general': 'Общие',
      'st.openNewTab': 'Открывать ссылки в новой вкладке',
      'st.boardColumns': 'Количество колонок',
      'st.boardWidth': 'Ширина досок',
      'st.colsAuto': 'Авто',
      'st.colsHint': (p) => `Ваш размер экрана вмещает максимум ${p.n} ${plRu(p.n, 'колонку', 'колонки', 'колонок')}.`,
      'st.hideExtra': 'Скрывать лишние закладки',
      'st.showN': (p) => `Показать ${p.n}`,
      'st.showDescriptions': 'Показывать описания',
      'st.quickSave': 'Быстрое сохранение',
      'st.saveToPage': 'Сохранять на страницу',
      'st.saveToBoard': 'Сохранять на доску',
      'st.shortcut': 'Горячая клавиша',
      'st.notSet': 'Не задано',
      'st.change': 'Изменить',
      'st.language': 'Язык',
      'st.langAuto': 'Авто',
      'st.region': 'Регион',
      'st.autoDetect': 'Автоопределение',
      'st.advancedOpen': 'Дополнительно ›',
      'st.advancedClose': 'Дополнительно ‹',
      'st.timeFormat': 'Формат времени',
      'st.dateFormat': 'Формат даты',
      'st.weekStart': 'Начало недели',
      'st.monday': 'Понедельник',
      'st.sunday': 'Воскресенье',
      'st.sidebar': 'Боковая панель',
      'st.alwaysShow': 'Всегда показывать все кнопки',
      'st.support': 'Поддержка',
      'st.version': 'Версия',
      'tour.skip': 'Пропустить тур',
      'tour.next': 'Далее →',
      'tour.done': 'Готово',
      'tour.importBookmarks': 'Импортировать закладки',
      'tour.maybeLater': 'Позже',
      'tour.counter': (p) => `${p.i} из ${p.total}`,
      'tour.boardsTitle': 'Ваши доски',
      'tour.boardsDesc': 'На доске лежат ваши закладки. Раскладывайте их так, как удобно именно вам.',
      'tour.addTitle': 'Добавьте закладку',
      'tour.addDesc': 'Нажмите + на любой доске, чтобы сохранить ссылку.',
      'tour.pagesTitle': 'Разложите по страницам',
      'tour.pagesDesc': 'Заведите отдельные страницы: работа, личное, путешествия, что угодно.',
      'tour.menuTitle': 'Загляните в меню',
      'tour.menuDesc': 'Здесь можно сменить обои, добавить виджеты и перенести закладки из Chrome.',
      'tour.settingsTitle': 'Настройки',
      'tour.settingsDesc': 'Аккаунт, вид досок и всё остальное собрано в одном месте.',
      'tour.saveTitle': 'Сохраняйте страницу в один клик',
      'tour.saveDesc': 'Нажмите на значок BlackCodex Bookmark Manager на панели браузера, чтобы сохранить открытую вкладку. А ещё можно задать горячую клавишу в настройках.',
      'tour.bringTitle': 'Перенесите свои закладки',
      'tour.bringDesc': 'Давайте перенесём ваши закладки из Chrome на доски. Это один клик.',
      'tour.dragTitle': 'Перетаскивайте закладки',
      'tour.dragDesc': 'Перетащите закладку на другую доску или поменяйте порядок внутри доски.',
      'tour.doneTitle': 'Всё готово!',
      'tour.doneDesc': 'Это всё, что нужно знать. Пользуйтесь и настраивайте под себя.',
      'cal.dayShort': ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
      'cal.monShort': ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'],
      'clock.days': ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
      'popup.quickSave': 'Быстрое сохранение',
      'popup.saveTo': 'Сохранить в BlackCodex Bookmark Manager',
      'popup.url': 'Ссылка',
      'popup.title': 'Название',
      'popup.titlePlaceholder': 'Заголовок страницы',
      'popup.page': 'Страница',
      'popup.board': 'Доска',
      'popup.save': 'Сохранить закладку',
      'popup.saved': 'Сохранено!',
      'popup.urlRequired': 'Укажите ссылку.',
      'popup.noData': 'Данные не найдены.',
      'popup.noBoards': 'Доски не найдены.',
      'popup.loadFail': 'Не удалось загрузить данные.',
    },
  };

  function interpolate(str, params) {
    if (!params) return str;
    return str.replace(/\{(\w+)\}/g, (m, k) => (params[k] != null ? params[k] : m));
  }

  function t(key, params) {
    let v = STR[lang][key];
    if (v === undefined) v = STR.en[key];
    if (v === undefined) return key;
    if (typeof v === 'function') return v(params || {});
    if (typeof v === 'string') return interpolate(v, params);
    return v; // arrays etc.
  }

  // Apply translations to static markup.
  //  data-i18n           → textContent
  //  data-i18n-html      → innerHTML (for strings containing <br>)
  //  data-i18n-ph        → placeholder attribute
  //  data-i18n-title     → title attribute
  //  data-i18n-aria      → aria-label attribute
  function applyStatic(root) {
    root = root || document;
    root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.getAttribute('data-i18n')); });
    root.querySelectorAll('[data-i18n-html]').forEach(el => { el.innerHTML = t(el.getAttribute('data-i18n-html')); });
    root.querySelectorAll('[data-i18n-ph]').forEach(el => { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph'))); });
    root.querySelectorAll('[data-i18n-title]').forEach(el => { el.setAttribute('title', t(el.getAttribute('data-i18n-title'))); });
    root.querySelectorAll('[data-i18n-aria]').forEach(el => { el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria'))); });
  }

  // Persist a language override and reload so everything re-renders.
  //  'auto' | 'en' | 'ru'
  function setLang(val) {
    try {
      if (val === 'auto') localStorage.removeItem(LANG_KEY);
      else localStorage.setItem(LANG_KEY, val);
    } catch (e) {}
    location.reload();
  }

  function currentPref() {
    try {
      const o = localStorage.getItem(LANG_KEY);
      return SUPPORTED.includes(o) ? o : 'auto';
    } catch (e) { return 'auto'; }
  }

  try { document.documentElement.lang = lang; } catch (e) {}

  window.I18N = { lang, t, applyStatic, setLang, currentPref };
})();
