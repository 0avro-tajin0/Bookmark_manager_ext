# 

# BlackCodex Cloud Sync — Setup Guide

Your extension's ID is now **fixed**: `fabfijlglminblgnfjcahkdobocjedec`
(baked into `manifest.json` via the `"key"` field). This is what makes
Google Sign-In work identically on both desktops — normally an unpacked
extension gets a random ID per machine, which would break auth. Keep
`extension-private-key.pem` somewhere safe; you don't need to install it
anywhere, it's just the private half of that key, for your records.

Load the **exact same folder contents** (with `manifest.json` as edited)
on both PCs so the ID matches on both. Don't regenerate or edit the `key`
field.

\---

## 1\. Create/reuse a Firebase project

1. Go to https://console.firebase.google.com → **Add project** (or reuse
your existing "Vault" project if you want one account across both apps —
totally fine, they'll just use separate Firestore collections).
2. In the project: **Build → Authentication → Get started → Sign-in method
→ Google → Enable**. Save.
3. **Build → Firestore Database → Create database** → Start in
**production mode** → pick a region → Enable.

## 2\. Get your Firebase Web API key + Project ID

1. Project settings (gear icon) → **General** tab.
2. Copy the **Project ID** (e.g. `blackcodex-12345`).
3. Under "Your apps", add a **Web app** (`</>` icon) if you don't have one
yet — you don't need to add the SDK snippet, just registering it gives
you the config.
4. Copy the **Web API Key** shown in that config (`apiKey: "..."`).

## 3\. Create the OAuth Client ID (Google Cloud Console)

1. Go to https://console.cloud.google.com/apis/credentials and select the
**same project** Firebase created for you (Firebase projects ARE Google
Cloud projects).
2. If prompted, configure the **OAuth consent screen** first:

   * User type: **External** (unless you have Workspace) → app name, your
email → Save through the steps. You can leave it in "Testing" mode
and add your own Google account under **Test users** — no need to
publish the consent screen for personal use.
3. **Create Credentials → OAuth client ID**:

   * Application type: **Chrome Extension**
   * Application ID: `fabfijlglminblgnfjcahkdobocjedec`
4. Copy the generated **Client ID** (ends in `.apps.googleusercontent.com`).

## 4\. Fill in the placeholders

**`manifest.json`** — replace:

```
"client\\\_id": "YOUR\\\_OAUTH\\\_CLIENT\\\_ID.apps.googleusercontent.com"
```

with the client ID from step 3.

**`sync.js`** — replace the top two constants:

```js
const FIREBASE\\\_API\\\_KEY = 'YOUR\\\_FIREBASE\\\_WEB\\\_API\\\_KEY';
const FIREBASE\\\_PROJECT\\\_ID = 'YOUR\\\_FIREBASE\\\_PROJECT\\\_ID';
```

with the values from step 2.

## 5\. Lock down Firestore so only you can read/write your data

Firestore → **Rules**, replace with:

```
rules\\\_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null \\\&\\\& request.auth.uid == uid;
    }
  }
}
```

Publish.

## 6\. Load it on both desktops

1. `chrome://extensions` → enable **Developer mode** → **Load unpacked** →
select the `blackcodex-bookmark-manager` folder.
2. Do this on **both** PCs, from the same edited folder contents (copy it
over, e.g. via a shared drive, USB, or GitHub repo — just make sure
`manifest.json`'s `key` field is untouched on both).
3. Open a new tab → open **Settings → Sync → Sign in with Google** → pick
your account → approve.
4. On the second desktop, do the same sign-in. Whichever device has
the most recently updated setup wins on first sign-in; after that,
changes on either device sync to the other automatically (polls every
\~45s while a new tab is open, plus immediately when you make a change).

## Notes / limits

* Wallpaper images are auto-downscaled before syncing (max 1600px, JPEG)
to stay under Firestore's 1MB-per-document limit. Very large or highly
detailed images may still get dropped from sync (the rest of your setup
still syncs fine) — a console warning will show if that happens.
* Video wallpapers are stored **locally per device only** (free —
no Firebase Storage / Blaze plan needed). They don't cross-sync
automatically; set the same video file on each desktop separately via
the wallpaper menu → Set video wallpaper if you want it on both.
* This is polling-based sync (not instant realtime), which is the right
tradeoff for a REST-only, no-SDK, no-bundler build like this one.
* If you ever want this on the Chrome Web Store: publish using this exact
`manifest.json` (with the `key` field) and the ID will stay
`fabfijlglminblgnfjcahkdobocjedec`, so sign-in keeps working without any
changes.

