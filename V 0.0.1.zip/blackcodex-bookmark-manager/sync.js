// ── Cloud Sync (Google Sign-In + Firestore) ──────────────────────────────
// No Firebase SDK is used (the extension's CSP only allows 'self' scripts,
// and the project intentionally has no bundler). Instead this talks to the
// Firebase Auth REST API and Firestore REST API directly with fetch().
//
// Setup required before this works — fill these two constants in:
const FIREBASE_API_KEY = 'AIzaSyDJ8FwKjLsLzsBNzT-WAUfNnFab40Kzkyg';
const FIREBASE_PROJECT_ID = 'bookmark-manger-blackcodex';

const Sync = (() => {
  const AUTH_KEY = 'syncAuth';           // chrome.storage.local key for tokens
  const POLL_MS = 45000;                 // background pull interval while tab open
  const MAX_WALLPAPER_DIM = 1600;        // downscale target so docs stay under Firestore's 1MB limit
  const WALLPAPER_QUALITY = 0.6;

  let _auth = null;      // { uid, email, idToken, refreshToken, expiresAt, googleToken }
  let _pushTimer = null;
  let _pollTimer = null;
  let _listeners = [];   // callbacks(state) fired on remote pull with newer data
  let _busy = false;

  function onRemoteUpdate(fn) { _listeners.push(fn); }
  function isSignedIn() { return !!_auth; }
  function currentUser() { return _auth ? { email: _auth.email, uid: _auth.uid } : null; }

  function loadAuthFromDisk() {
    return new Promise(resolve => {
      chrome.storage.local.get(AUTH_KEY, res => {
        _auth = res[AUTH_KEY] || null;
        resolve(_auth);
      });
    });
  }
  function persistAuth() {
    return new Promise(resolve => {
      chrome.storage.local.set({ [AUTH_KEY]: _auth }, resolve);
    });
  }
  function clearAuth() {
    _auth = null;
    return new Promise(resolve => chrome.storage.local.remove(AUTH_KEY, resolve));
  }

  // ── Sign in / out ──
  function signIn() {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, async (googleToken) => {
        if (chrome.runtime.lastError || !googleToken) {
          reject(chrome.runtime.lastError || new Error('No token returned'));
          return;
        }
        try {
          const res = await fetch(
            `https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${FIREBASE_API_KEY}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                postBody: `access_token=${googleToken}&providerId=google.com`,
                requestUri: 'https://blackcodex.local',
                returnSecureToken: true
              })
            }
          );
          const data = await res.json();
          if (data.error) throw new Error(data.error.message || 'Sign-in failed');
          _auth = {
            uid: data.localId,
            email: data.email,
            idToken: data.idToken,
            refreshToken: data.refreshToken,
            expiresAt: Date.now() + (Number(data.expiresIn || 3600) * 1000) - 60000,
            googleToken
          };
          await persistAuth();
          resolve(_auth);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  function signOut() {
    stopPolling();
    return new Promise(resolve => {
      const tok = _auth && _auth.googleToken;
      clearAuth().then(() => {
        if (tok && chrome.identity && chrome.identity.removeCachedAuthToken) {
          chrome.identity.removeCachedAuthToken({ token: tok }, () => resolve());
        } else resolve();
      });
    });
  }

  async function ensureFreshToken() {
    if (!_auth) return null;
    if (Date.now() < _auth.expiresAt) return _auth.idToken;
    const res = await fetch(`https://securetoken.googleapis.com/v1/token?key=${FIREBASE_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(_auth.refreshToken)}`
    });
    const data = await res.json();
    if (data.error) { await signOut(); return null; }
    _auth.idToken = data.id_token;
    _auth.refreshToken = data.refresh_token;
    _auth.expiresAt = Date.now() + (Number(data.expires_in || 3600) * 1000) - 60000;
    await persistAuth();
    return _auth.idToken;
  }

  // ── Wallpaper downscale so the whole doc stays under Firestore's 1MB cap ──
  function shrinkWallpaper(dataUrl) {
    return new Promise(resolve => {
      if (!dataUrl) { resolve(null); return; }
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        const scale = Math.min(1, MAX_WALLPAPER_DIM / Math.max(width, height));
        width = Math.round(width * scale);
        height = Math.round(height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', WALLPAPER_QUALITY));
      };
      img.onerror = () => resolve(null); // drop wallpaper from sync rather than fail the whole push
      img.src = dataUrl;
    });
  }

  // ── Firestore push/pull ──
  function docUrl(uid) {
    return `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/users/${uid}`;
  }

  async function pushState(state) {
    if (!_auth || _busy) return;
    const token = await ensureFreshToken();
    if (!token) return;
    _busy = true;
    try {
      const clone = JSON.parse(JSON.stringify(state));
      clone.updatedAt = clone.updatedAt || Date.now();
      if (clone.customWallpaper) {
        const small = await shrinkWallpaper(clone.customWallpaper);
        clone.customWallpaper = small; // null if it failed to shrink — still syncs the rest
      }
      let json = JSON.stringify(clone);
      // Hard safety net: if still too big (huge board/bookmark counts), drop wallpaper entirely.
      if (json.length > 950000 && clone.customWallpaper) {
        clone.customWallpaper = null;
        json = JSON.stringify(clone);
      }
      const url = `${docUrl(_auth.uid)}?updateMask.fieldPaths=data&updateMask.fieldPaths=updatedAt`;
      await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          fields: {
            data: { stringValue: json },
            updatedAt: { integerValue: String(clone.updatedAt) }
          }
        })
      });
    } catch (err) {
      console.error('[Sync] push failed:', err);
    } finally {
      _busy = false;
    }
  }

  function schedulePush(state) {
    if (!_auth) return;
    clearTimeout(_pushTimer);
    _pushTimer = setTimeout(() => pushState(state), 1500);
  }

  async function pullState() {
    if (!_auth) return null;
    const token = await ensureFreshToken();
    if (!token) return null;
    try {
      const res = await fetch(docUrl(_auth.uid), { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 404) return null; // nothing pushed yet from any device
      const data = await res.json();
      const raw = data.fields && data.fields.data && data.fields.data.stringValue;
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (err) {
      console.error('[Sync] pull failed:', err);
      return null;
    }
  }

  function startPolling() {
    stopPolling();
    _pollTimer = setInterval(checkRemote, POLL_MS);
    document.addEventListener('visibilitychange', onVisible);
  }
  function stopPolling() {
    clearInterval(_pollTimer);
    document.removeEventListener('visibilitychange', onVisible);
  }
  function onVisible() { if (!document.hidden) checkRemote(); }

  async function checkRemote() {
    if (!_auth) return;
    const remote = await pullState();
    if (remote) _listeners.forEach(fn => fn(remote));
  }

  // ── Called once on startup: signs in silently if a session exists,
  //    reconciles local vs remote by comparing updatedAt, and starts polling. ──
  async function init(localState) {
    await loadAuthFromDisk();
    if (!_auth) return { signedIn: false, resolvedState: null };
    const remote = await pullState();
    startPolling();
    if (!remote) {
      // Nothing in the cloud yet for this account — push what we have locally.
      schedulePush(localState);
      return { signedIn: true, resolvedState: null };
    }
    const remoteNewer = (remote.updatedAt || 0) > (localState.updatedAt || 0);
    if (remoteNewer) return { signedIn: true, resolvedState: remote };
    schedulePush(localState);
    return { signedIn: true, resolvedState: null };
  }

  return {
    signIn, signOut, isSignedIn, currentUser,
    init, schedulePush, pushState, pullState, onRemoteUpdate
  };
})();
window.Sync = Sync;
