
// Analytics removed for personal-use build. Stubs keep existing call sites harmless.
function track() {}
function trackOnce() {}
function trackDaily() {}
window.setAnalyticsUser = function () {};

// Localization shortcut. i18n.js loads before this file.
const T = (k, p) => (window.I18N ? I18N.t(k, p) : k);

// Apply translations to the static markup (all overlays already parsed since
// this script runs at the end of <body>).
(function () {
  try { I18N.applyStatic(document); } catch (e) {}
})();

// ── State ──
let S = {};

const DEFAULTS = {
  pages: [{ id: 'p1', name: 'Home', order: 0 }],
  boards: [
    { id: 'b1', pageId: 'p1', name: 'Work', col: 0, row: 0 },
    { id: 'b2', pageId: 'p1', name: 'Reading', col: 1, row: 0 },
    { id: 'b3', pageId: 'p1', name: 'Personal', col: 2, row: 0 }
  ],
  trash: { boards: [], bookmarks: [] },
  themeStyle: { boardColorHex: '#ffffff', boardOpacity: 5, boardBlur: 12, accentHex: '#ffffff', isDark: true, textScale: 1, textBold: false },
  bookmarks: [
    { id: 'bk1', boardId: 'b1', url: 'https://notion.so', title: 'Notion', order: 0, isDemo: true },
    { id: 'bk2', boardId: 'b1', url: 'https://figma.com', title: 'Figma', order: 1, isDemo: true },
    { id: 'bk3', boardId: 'b2', url: 'https://news.ycombinator.com', title: 'Hacker News', order: 0, isDemo: true },
    { id: 'bk4', boardId: 'b2', url: 'https://medium.com', title: 'Medium', order: 1, isDemo: true },
    { id: 'bk5', boardId: 'b3', url: 'https://gmail.com', title: 'Gmail', order: 0, isDemo: true },
    { id: 'bk6', boardId: 'b3', url: 'https://youtube.com', title: 'YouTube', order: 1, isDemo: true }
  ],
  activePage: 'p1'
};

function genId() { return '_' + Math.random().toString(36).slice(2, 10); }

function detectLocale() {
  const lang = navigator.language || 'en';
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';

  // Time format + date order: language is the right signal (display preference)
  let timeFormat = '24h';
  try {
    if (new Intl.DateTimeFormat(lang, { hour: 'numeric' }).resolvedOptions().hour12) timeFormat = '12h';
  } catch(e) {}

  let dateFormat = 'DMY';
  try {
    const parts = new Intl.DateTimeFormat(lang).formatToParts(new Date(2024, 0, 31));
    const order = parts.filter(p => ['day','month','year'].includes(p.type)).map(p => p.type[0]);
    if (order[0] === 'm') dateFormat = 'MDY';
    else if (order[0] === 'y') dateFormat = 'YMD';
  } catch(e) {}

  // Week start: timezone only — Intl.Locale uses browser language, not actual location
  // Europe + Africa → Monday; everywhere else → Sunday
  const weekStart = /^(Europe|Africa)/.test(tz) ? 1 : 0;

  // Temperature: whitelist of US IANA timezones → imperial; everything else → metric
  const US_TZ = new Set([
    'America/New_York','America/Detroit','America/Kentucky/Louisville','America/Kentucky/Monticello',
    'America/Indiana/Indianapolis','America/Indiana/Vincennes','America/Indiana/Winamac',
    'America/Indiana/Marengo','America/Indiana/Petersburg','America/Indiana/Vevay',
    'America/Chicago','America/Indiana/Tell_City','America/Indiana/Knox','America/Menominee',
    'America/North_Dakota/Center','America/North_Dakota/New_Salem','America/North_Dakota/Beulah',
    'America/Denver','America/Boise','America/Los_Angeles','America/Juneau','America/Sitka',
    'America/Metlakatla','America/Yakutat','America/Anchorage','America/Nome','America/Adak',
    'America/Phoenix','Pacific/Honolulu','America/Puerto_Rico','Pacific/Guam','Pacific/Saipan',
    'Pacific/Pago_Pago','America/St_Thomas',
  ]);
  const tempUnit = US_TZ.has(tz) ? 'imperial' : 'metric';

  return { timeFormat, dateFormat, weekStart, tempUnit, _v: 3 };
}

function getLayoutParams() {
  const GAP = 14;
  const MIN_W = 190;                 // narrowest a board may shrink to
  // The floating sidebar (settings / menu) is fixed ~64px in from the right edge.
  // The grid is centered, so we reserve a symmetric band on BOTH sides — the grid
  // then can never slide under those buttons, on any screen width.
  const SIDE_RESERVE = 76;           // 64px sidebar zone + ~12px breathing gap
  const usable = Math.max(MIN_W, window.innerWidth - 2 * SIDE_RESERVE);
  const requestedW = S.boardWidth || 260;

  // Absolute column ceiling: how many boards fit even at the minimum width.
  const maxCols = Math.max(1, Math.floor((usable + GAP) / (MIN_W + GAP)));
  const manual = S.maxBoardCols;
  const numCols = (manual && manual > 0)
    ? Math.min(manual, maxCols)      // count is user-fixed; only the screen ceiling caps it
    : Math.min(maxCols, Math.max(1, Math.floor((usable + GAP) / (requestedW + GAP))));

  // Clamp width so numCols boards always fit the usable band (never overlap the
  // sidebar). This is what makes "4 columns" allow a wider board than "5 columns":
  // fewer columns → more room each → the cap rises automatically.
  const fitW = Math.floor((usable - (numCols - 1) * GAP) / numCols);
  const BOARD_W = Math.max(MIN_W, Math.min(requestedW, fitW));

  return { BOARD_W, GAP, numCols, autoCols: maxCols, fitW };
}

// Video wallpaper data lives OUTSIDE of `S`/appState entirely — it's stored
// under its own chrome.storage.local key and never synced to Firestore
// (keeps everyone on the free Spark plan; no Firebase Storage needed).
// It also means the video itself doesn't cross devices automatically —
// only the fact that "a video wallpaper is set" (S.wallpaperType) does.
let _localWallpaperVideo = null;

function loadState() {
  return new Promise(resolve => {
    chrome.storage.local.get(['appState', 'wallpaperVideoData'], res => {
      S = res.appState ? res.appState : JSON.parse(JSON.stringify(DEFAULTS));
      _localWallpaperVideo = res.wallpaperVideoData || null;
      if (!S.activePage || !S.pages.find(p => p.id === S.activePage)) {
        S.activePage = S.pages[0]?.id || null;
      }
      if (!S.trash) S.trash = { boards: [], bookmarks: [] };
      if (!S.focusStats) S.focusStats = [];
      if (!S.pomTimers) S.pomTimers = {};
      if (!S.themeStyle) S.themeStyle = { boardColorHex:'#ffffff', boardOpacity:5, boardBlur:12, accentHex:'#ffffff', isDark:true, textScale:1, textBold:false };
      if (!S.locale || S.locale._v !== 3) S.locale = detectLocale();
      if (S.openInNewTab === undefined) S.openInNewTab = true;
      if (S.incognito === undefined) S.incognito = false;
      if (S.clockEnabled === undefined) S.clockEnabled = false;
      if (S.navSearchEnabled === undefined) S.navSearchEnabled = true;
      if (S.hideExtraBookmarks === undefined) S.hideExtraBookmarks = false;
      if (!S.maxBookmarksShown) S.maxBookmarksShown = 5;
      if (S.showDescriptions === undefined) S.showDescriptions = true;
      if (S.sidebarAlwaysExpanded === undefined) S.sidebarAlwaysExpanded = false;
      if (!S.quickSaveBoard) S.quickSaveBoard = '';
      if (!S.locale || S.locale._v !== 3) S.locale = detectLocale();
      if (S.customWallpaper === undefined) S.customWallpaper = null;
      if (S.wallpaperType === undefined) S.wallpaperType = S.customWallpaper ? 'image' : null;
      applyThemeStyle(S.themeStyle);
      // Migrate boards to col/row model
      S.boards.forEach((b, i) => {
        // Per-board customization was removed — drop any leftover style data.
        if (b.boardStyle) delete b.boardStyle;
        if (b.col == null) {
          if (b.x != null) {
            b.col = Math.round(b.x / 274);
            b.row = Math.round(b.y / 220);
          } else {
            const idx = b.order != null ? b.order : i;
            b.col = idx % 4;
            b.row = Math.floor(idx / 4);
          }
          delete b.x; delete b.y; delete b.order;
        }
      });
      resolve();
    });
  });
}

// Unique per open tab, stamped onto every write we make so the storage.onChanged
// listener can tell our own writes apart from external ones (e.g. the Quick Save
// popup) without a racy boolean flag.
const _tabId = 'tab_' + Math.random().toString(36).slice(2);

let _saveTimer = null;
function saveState() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    S._writer = _tabId;
    S.updatedAt = Date.now();
    chrome.storage.local.set({ appState: S });
    if (window.Sync) Sync.schedulePush(S);
  }, 300);
}

// ── Deferred reconcile ──
// Cross-tab live updates (e.g. Quick Save from the toolbar popup while this
// tab is open) re-render the whole page. If that fires while the user is
// mid-interaction — typing a new board name or search query, editing a popup
// field, dragging, or with a popup/menu open — the rebuild would destroy the
// focused input (losing focus + typed text) or detach a popup's anchor
// (sending it to the top-left corner). So while the user is busy we hold only
// the NEWEST reconcile and run it once they go idle.
let _deferredReconcile = null;

function isUserBusy() {
  const ae = document.activeElement;
  if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT' || ae.isContentEditable)) return true;
  if (_dragId) return true;
  if (document.querySelector('.bk-popup, .board-menu, .focus-stats-popup, .nsb-eng-popup, .pom-settings-popup')) return true;
  return false;
}

function reconcileOrDefer(fn) {
  if (isUserBusy()) { _deferredReconcile = fn; return; }
  fn();
}

function flushDeferredReconcile() {
  if (_deferredReconcile && !isUserBusy()) {
    const fn = _deferredReconcile;
    _deferredReconcile = null;
    fn();
  }
}
// Retry the flush right after the user finishes an interaction.
document.addEventListener('focusout', () => setTimeout(flushDeferredReconcile, 200));
document.addEventListener('dragend',  () => setTimeout(flushDeferredReconcile, 200));
document.addEventListener('click',    () => setTimeout(flushDeferredReconcile, 200));

// Reflect external writes to local appState (e.g. Quick Save from the toolbar
// popup, or another open tab) so the page updates live instead of needing a
// manual refresh — and so our next saveState() doesn't clobber the addition.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.appState) return;
  const nv = changes.appState.newValue;
  if (!nv || nv._writer === _tabId) return; // our own write
  reconcileOrDefer(() => {
    loadState().then(() => {
      renderAll();
    });
  });
});

// ── Favicon ──
// Each service should show its real icon, so we build a chain of sources and
// walk it via onerror. The old single fallback was google.com/s2/favicons,
// which collapses every Google product (Gmail, Calendar, …) to a generic "G".
const MULTI_PART_TLDS = [
  'co.uk','com.au','co.jp','co.nz','co.za','com.br','com.mx',
  'co.in','org.uk','gov.uk','ac.uk','com.tr','com.ar','com.sg'
];

function getRootDomain(host) {
  const t = host.split('.');
  if (t.length <= 2) return host;
  const last2 = t.slice(-2).join('.');
  if (MULTI_PART_TLDS.includes(last2)) return t.length <= 3 ? host : t.slice(-3).join('.');
  return last2;
}

// Google products can't be resolved from their bare domain — gmail.com,
// mail.google.com, etc. all report a generic "G" to every favicon service.
// So we hardcode the real product icons (same approach as competitors). Keys
// are hostname, or "hostname/firstPathSegment" for products that share a host
// (docs.google.com/spreadsheets, …). Checked before any network source.
const KNOWN_FAVICONS = {
  'gmail.com':                    'https://ssl.gstatic.com/images/branding/product/2x/gmail_2020q4_48dp.png',
  'mail.google.com':             'https://ssl.gstatic.com/images/branding/product/2x/gmail_2020q4_48dp.png',
  'calendar.google.com':         'https://ssl.gstatic.com/images/branding/product/2x/calendar_2020q4_48dp.png',
  'drive.google.com':            'https://ssl.gstatic.com/images/branding/product/2x/drive_2020q4_48dp.png',
  'meet.google.com':             'https://ssl.gstatic.com/images/branding/product/2x/meet_2020q4_48dp.png',
  'chat.google.com':             'https://ssl.gstatic.com/images/branding/product/2x/chat_2020q4_48dp.png',
  'keep.google.com':             'https://ssl.gstatic.com/images/branding/product/2x/keep_2020q4_48dp.png',
  'photos.google.com':           'https://ssl.gstatic.com/images/branding/product/2x/photos_48dp.png',
  'contacts.google.com':         'https://www.gstatic.com/images/branding/product/1x/contacts_2022_48dp.png',
  'translate.google.com':        'https://ssl.gstatic.com/images/branding/product/2x/translate_48dp.png',
  'maps.google.com':             'https://www.gstatic.com/images/branding/product/2x/maps_48dp.png',
  'google.com/maps':             'https://www.gstatic.com/images/branding/product/2x/maps_48dp.png',
  'www.google.com/maps':         'https://www.gstatic.com/images/branding/product/2x/maps_48dp.png',
  'docs.google.com':             'https://ssl.gstatic.com/docs/documents/images/kix-favicon7.ico',
  'docs.google.com/document':    'https://ssl.gstatic.com/docs/documents/images/kix-favicon7.ico',
  'docs.google.com/spreadsheets':'https://ssl.gstatic.com/docs/spreadsheets/favicon3.ico',
  'docs.google.com/presentation':'https://ssl.gstatic.com/docs/presentations/images/favicon5.ico',
  'docs.google.com/forms':       'https://ssl.gstatic.com/docs/forms/device_home/android_192.png',
  'google.com':                  'https://ssl.gstatic.com/images/branding/product/1x/googleg_48dp.png',
  'www.google.com':              'https://ssl.gstatic.com/images/branding/product/1x/googleg_48dp.png',
};

function knownFavicon(u) {
  const host = u.hostname.toLowerCase();
  const seg1 = u.pathname.split('/').filter(Boolean)[0];
  if (seg1 && KNOWN_FAVICONS[host + '/' + seg1]) return KNOWN_FAVICONS[host + '/' + seg1];
  return KNOWN_FAVICONS[host] || null;
}

// Chrome's own favicon cache (needs "favicon" permission). Only knows icons for
// sites the user has actually visited, so it's the LAST resort — useful when a
// site serves no public favicon.ico but the browser cached one. It always
// yields an image (a default globe when nothing is cached) and never fires
// onerror, so it must come last in the chain.
function chromeFaviconUrl(pageUrl, size = 32) {
  try {
    const u = new URL(chrome.runtime.getURL('/_favicon/'));
    u.searchParams.set('pageUrl', pageUrl);
    u.searchParams.set('size', String(size));
    return u.toString();
  } catch { return ''; }
}

// Google's faviconV2 resolves the FULL page URL the way Chrome does, so every
// Google product on its own subdomain (gemini/mail/drive/calendar/photos/…)
// returns its real icon — not the generic google.com "G" that the old
// domain-based s2 endpoint gave. (Path-only products like www.google.com/maps
// still need the hardcoded map, since this keys off the origin.)
function faviconV2Url(pageUrl, size = 64) {
  return 'https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size='
    + size + '&url=' + encodeURIComponent(pageUrl);
}

function faviconCandidates(url) {
  const list = [];
  try {
    const u = new URL(url);
    const host = u.hostname;
    const root = getRootDomain(host);
    // 1. Hardcoded brand icons (Google products) — works without ever visiting.
    const known = knownFavicon(u);
    if (known) list.push(known);
    // 2. faviconV2 by full URL: resolves Google subdomain products correctly.
    //    Must come before the root-domain / ddg-root fallbacks below, which for
    //    a subdomain (gemini.google.com) would return the parent google.com "G".
    //    (A direct fetch of `<origin>/favicon.ico` used to sit here, but from a
    //    chrome-extension:// origin almost every site's favicon.ico rejects it
    //    under CORS — it never succeeded, it just spammed the console.)
    list.push(faviconV2Url(url));
    list.push('https://icons.duckduckgo.com/ip3/' + host + '.ico');
    if (root && root !== host) list.push('https://icons.duckduckgo.com/ip3/' + root + '.ico');
    // 3. Chrome's cache as a final guaranteed image (real icon if visited).
    const chromeUrl = chromeFaviconUrl(url);
    if (chromeUrl) list.push(chromeUrl);
  } catch {}
  return list.filter(Boolean);
}

// Favicons are cached as data URLs in chrome.storage.local. Boards re-render on
// every drag/page switch (recreating these <img>s) and the whole page reloads
// each time a new tab opens — without a cache, setFavicon re-walks the network
// chain every time and the first candidate's 404 → swap flickers. Storing the
// actual bytes means a cached icon paints instantly, offline, with no network.
const FAVICON_STORE_KEY = 'faviconCache';
const FAVICON_CACHE_VERSION = 4;               // bump to discard & rebuild the cache
const FAVICON_TTL = 1000 * 60 * 60 * 24 * 30; // refresh icons older than 30 days
const FAVICON_PX = 48;                         // re-encode every icon to this size
const _faviconCache = new Map();   // cacheKey -> data: URL
const _faviconTime = new Map();    // cacheKey -> timestamp (ms)
const _faviconResolving = new Set();
let _faviconDirty = false;
let _faviconSaveTimer = null;

// Key by hostname so all bookmarks of a site share one icon, but keep path
// granularity where we have per-path icons (docs.google.com/spreadsheets, …).
function faviconCacheKey(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    const seg1 = u.pathname.split('/').filter(Boolean)[0];
    if (seg1 && KNOWN_FAVICONS[host + '/' + seg1]) return host + '/' + seg1;
    return host;
  } catch { return url; }
}

function loadFaviconCache() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get(FAVICON_STORE_KEY, res => {
        const obj = res && res[FAVICON_STORE_KEY];
        // Discard the whole cache on a version bump so entries poisoned by older
        // logic get rebuilt cleanly instead of breaking a site forever.
        if (obj && typeof obj === 'object' && obj.__v === FAVICON_CACHE_VERSION) {
          for (const k in obj) {
            if (k === '__v') continue;
            const v = obj[k];
            if (typeof v === 'string') { _faviconCache.set(k, v); _faviconTime.set(k, 0); }
            else if (v && typeof v.d === 'string') { _faviconCache.set(k, v.d); _faviconTime.set(k, v.t || 0); }
          }
        }
        resolve();
      });
    } catch { resolve(); }
  });
}

function scheduleFaviconSave() {
  if (_faviconSaveTimer) return;
  _faviconSaveTimer = setTimeout(() => {
    _faviconSaveTimer = null;
    if (!_faviconDirty) return;
    _faviconDirty = false;
    const obj = { __v: FAVICON_CACHE_VERSION };
    for (const [k, v] of _faviconCache) obj[k] = { d: v, t: _faviconTime.get(k) || 0 };
    try { chrome.storage.local.set({ [FAVICON_STORE_KEY]: obj }); } catch {}
  }, 2000);
}

function evictFavicon(key) {
  if (!_faviconCache.has(key)) return;
  _faviconCache.delete(key);
  _faviconTime.delete(key);
  _faviconDirty = true;
  scheduleFaviconSave();
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = reject;
    fr.readAsDataURL(blob);
  });
}

// Fetch one icon source and re-encode it to a small PNG data URL. Returns null
// if the source can't be fetched, decoded, or renders fully transparent. We
// ALWAYS go through PNG: caching the raw bytes of some .ico files (a 2-colour
// icon Chrome decodes to transparency, or a malformed oversized one) produced
// an entry that loaded but showed nothing in the extension — the regression
// behind "site X stopped showing its favicon".
async function reencodeFaviconToPng(src) {
  try {
    const res = await fetch(src);
    if (!res.ok) return null;
    const blob = await res.blob();
    if (!blob.size || !/^image\//.test(blob.type)) return null;
    const bmp = await createImageBitmap(blob); // throws on undecodable bytes
    const canvas = new OffscreenCanvas(FAVICON_PX, FAVICON_PX);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bmp, 0, 0, FAVICON_PX, FAVICON_PX);
    bmp.close && bmp.close();
    const px = ctx.getImageData(0, 0, FAVICON_PX, FAVICON_PX).data;
    let visible = false;
    for (let p = 3; p < px.length; p += 4) { if (px[p] !== 0) { visible = true; break; } }
    if (!visible) return null;
    const out = await canvas.convertToBlob({ type: 'image/png' });
    if (!out.size || out.size > 200000) return null;
    const dataUrl = await blobToDataUrl(out);
    return (typeof dataUrl === 'string' && dataUrl.startsWith('data:image')) ? dataUrl : null;
  } catch { return null; }
}

// Resolve a bookmark's favicon for caching: walk the candidate sources and keep
// the first that re-encodes to a visible PNG. So if a site's own favicon.ico is
// undecodable, we fall through to DuckDuckGo / Google which serve clean PNGs.
async function resolveAndCacheFavicon(key, url, force = false) {
  const have = _faviconCache.get(key);
  if (!force && typeof have === 'string' && have.startsWith('data:')) return;
  if (_faviconResolving.has(key)) return;
  _faviconResolving.add(key);
  try {
    const cands = faviconCandidates(url).filter(c => !c.startsWith('data:'));
    for (const src of cands) {
      const dataUrl = await reencodeFaviconToPng(src);
      if (dataUrl) {
        _faviconCache.set(key, dataUrl);
        _faviconTime.set(key, Date.now());
        _faviconDirty = true;
        scheduleFaviconSave();
        return;
      }
    }
  } finally { _faviconResolving.delete(key); }
}

// Re-resolve a stale icon in the background (handles sites that rebrand). The
// displayed icon keeps using the cached copy; only the stored bytes update.
function maybeRefreshFavicon(key, url) {
  if (Date.now() - (_faviconTime.get(key) || 0) < FAVICON_TTL) return;
  // Mark as fresh now so a failed refresh won't retry on every render.
  _faviconTime.set(key, Date.now());
  _faviconDirty = true;
  scheduleFaviconSave();
  resolveAndCacheFavicon(key, url, true);
}

function setFavicon(img, url) {
  const key = faviconCacheKey(url);
  let candidates = faviconCandidates(url);
  const cached = _faviconCache.get(key);
  if (cached) {
    candidates = [cached, ...candidates.filter(c => c !== cached)];
    maybeRefreshFavicon(key, url);
  }
  let i = 0;
  function next() {
    if (i >= candidates.length) { img.onerror = null; img.onload = null; img.style.visibility = 'hidden'; return; }
    img.src = candidates[i++];
  }
  img.onload = () => {
    // Something is on screen; make sure a clean PNG is cached for next time.
    if (!_faviconCache.has(key)) resolveAndCacheFavicon(key, url);
  };
  img.onerror = () => {
    // A cached entry that no longer loads is poison — drop it and re-resolve.
    if (cached && img.src === cached) evictFavicon(key);
    next();
  };
  next();
}

// ── Render ──
function updateNavLayout() {
  const nav = document.getElementById('pagesNav');
  if (!nav) return;

  const navLeft = nav.getBoundingClientRect().left;
  let rightBound = null;

  const nsbBar = document.querySelector('.nsb-bar');
  if (nsbBar) {
    const r = nsbBar.getBoundingClientRect();
    if (r.width > 0) rightBound = r.left;
  }

  const widgets = document.getElementById('topWidgets');
  if (widgets) {
    const wLeft = widgets.getBoundingClientRect().left;
    rightBound = rightBound !== null ? Math.min(rightBound, wLeft) : wLeft;
  }

  if (rightBound !== null && rightBound > navLeft) {
    nav.style.maxWidth = Math.max(80, rightBound - navLeft - 16) + 'px';
  } else {
    nav.style.maxWidth = '';
  }

  _updateScrollThumb?.();
}

function syncLayout() {
  const topbar = document.querySelector('.topbar');
  if (!topbar) return;
  const colItems = document.querySelectorAll('.boards-columns > .board-column');
  if (!colItems.length) { topbar.style.width = ''; topbar.style.marginLeft = ''; updateNavLayout(); return; }
  const first = colItems[0].getBoundingClientRect();
  const last  = colItems[colItems.length - 1].getBoundingClientRect();
  topbar.style.width = (last.right - first.left) + 'px';
  topbar.style.marginLeft = first.left + 'px';
  updateNavLayout();
}

function renderAll() { renderPages(); renderBoards(); renderNavSearch(); requestAnimationFrame(syncLayout); }

function renderPages() {
  const nav = document.getElementById('pagesNav');
  const prevScroll = nav.querySelector('.tabs-group')?.scrollLeft || 0;
  nav.innerHTML = '';


  const group = document.createElement('div');
  group.className = 'tabs-group';

  let _dragId = null;

  function clearDropIndicators() {
    group.querySelectorAll('.tab-drop-indicator').forEach(el => el.remove());
    group.querySelectorAll('.page-tab').forEach(t => t.classList.remove('drag-over'));
  }

  [...S.pages].sort((a, b) => a.order - b.order).forEach(page => {
    const tab = document.createElement('div');
    tab.className = 'page-tab' + (page.id === S.activePage ? ' active' : '');
    tab.dataset.id = page.id;
    tab.draggable = true;

    const name = document.createElement('span');
    name.className = 'page-tab-name';
    name.textContent = page.name;
    name.addEventListener('dblclick', e => { e.stopPropagation(); startPageRename(page.id, name); });
    tab.appendChild(name);

    tab.addEventListener('click', () => switchPage(page.id));
    tab.addEventListener('contextmenu', e => {
      e.preventDefault();
      e.stopPropagation();
      showPageMenu(page.id, e.clientX, e.clientY);
    });

    tab.addEventListener('dragstart', e => {
      _dragId = page.id;
      e.dataTransfer.effectAllowed = 'move';
      setTimeout(() => tab.classList.add('dragging'), 0);
    });

    tab.addEventListener('dragend', () => {
      _dragId = null;
      tab.classList.remove('dragging');
      clearDropIndicators();
    });

    tab.addEventListener('dragover', e => {
      if (!_dragId || _dragId === page.id) return;
      e.preventDefault();
      clearDropIndicators();
      const rect = tab.getBoundingClientRect();
      const before = e.clientX < rect.left + rect.width / 2;
      const indicator = document.createElement('div');
      indicator.className = 'tab-drop-indicator';
      group.insertBefore(indicator, before ? tab : tab.nextSibling);
    });

    tab.addEventListener('drop', e => {
      e.preventDefault();
      if (!_dragId || _dragId === page.id) return;
      clearDropIndicators();
      const rect = tab.getBoundingClientRect();
      const before = e.clientX < rect.left + rect.width / 2;
      const sorted = [...S.pages].sort((a, b) => a.order - b.order);
      const fromIdx = sorted.findIndex(p => p.id === _dragId);
      const [dragged] = sorted.splice(fromIdx, 1);
      const toIdx = sorted.findIndex(p => p.id === page.id);
      sorted.splice(before ? toIdx : toIdx + 1, 0, dragged);
      sorted.forEach((p, i) => { p.order = i; });
      saveState();
      renderPages();
    });

    group.appendChild(tab);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'add-page-btn';
  addBtn.title = T('tip.newPage');
  addBtn.setAttribute('data-tour', 'add-page');
  addBtn.innerHTML = `<span style="font-size:20px;line-height:1;font-weight:300;">+</span>`;
  addBtn.addEventListener('click', addPage);
  group.appendChild(addBtn);

  nav.appendChild(group);

  // Scrollbar inside tabs-group
  const scrollBar = document.createElement('div');
  scrollBar.className = 'tabs-scroll-bar';
  const scrollThumb = document.createElement('div');
  scrollThumb.className = 'tabs-scroll-thumb';
  scrollBar.appendChild(scrollThumb);
  nav.appendChild(scrollBar);

  function updateScrollThumb() {
    const visible = group.clientWidth;
    const total = group.scrollWidth;
    const ratio = visible / total;
    const hasScroll = ratio < 0.999;
    scrollBar.style.opacity = hasScroll ? '1' : '0';
    scrollThumb.style.width = (ratio * 100) + '%';
    scrollThumb.style.left = ((group.scrollLeft / total) * 100) + '%';
    const atEnd = group.scrollLeft + visible >= total - 2;
    nav.classList.toggle('has-overflow', hasScroll && !atEnd);
  }
  _updateScrollThumb = updateScrollThumb;

  group.addEventListener('scroll', updateScrollThumb);

  // Click on track → jump to position
  scrollBar.addEventListener('mousedown', e => {
    if (e.target === scrollThumb) return;
    const rect = scrollBar.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    group.scrollLeft = pct * group.scrollWidth - group.clientWidth / 2;
    e.preventDefault();
  });

  // Drag thumb
  scrollThumb.addEventListener('mousedown', e => {
    e.preventDefault();
    const startX = e.clientX;
    const startScroll = group.scrollLeft;
    const barW = scrollBar.clientWidth;
    const total = group.scrollWidth;
    function onMove(ev) {
      const dx = ev.clientX - startX;
      group.scrollLeft = startScroll + (dx / barW) * total;
    }
    function onUp() {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    }
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  requestAnimationFrame(() => {
    group.scrollLeft = prevScroll;
    updateNavLayout();
    updateScrollThumb();
  });
}

function renderNavSearch() {
  const el = document.getElementById('navSearchBar');
  if (!el) return;
  if (!S.navSearchEnabled) { el.innerHTML = ''; closeNsbEnginePopup(); return; }
  const prevVal = el.querySelector('.nsb-input')?.value || '';
  el.innerHTML = '';

  const bar = document.createElement('div');
  bar.className = 'nsb-bar';

  // Static search icon (left)
  bar.insertAdjacentHTML('beforeend', `<svg class="nsb-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`);

  // Text input
  const input = document.createElement('input');
  input.className = 'nsb-input';
  input.type = 'text';
  input.placeholder = T('search.widgetPlaceholder');
  input.value = prevVal;
  input.autocomplete = 'off';
  input.spellcheck = false;
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && input.value.trim()) {
      nsbDoSearch(input.value.trim());
      input.value = '';
    }
    if (e.key === 'Escape') { closeNsbEnginePopup(); input.blur(); }
  });
  bar.appendChild(input);

  // Engine icon button (right) — shows current engine, click opens picker
  const curEngId = S.navSearchEngine || 'google';
  const curEng = SEARCH_ENGINES.find(e => e.id === curEngId) || SEARCH_ENGINES[1];
  const engBtn = document.createElement('button');
  engBtn.className = 'nsb-eng-logo';
  engBtn.title = `Engine: ${curEng.name}`;
  engBtn.appendChild(nsbEngineIcon(curEng, 16));
  engBtn.addEventListener('click', e => { e.stopPropagation(); openNsbEnginePopup(engBtn); });
  bar.appendChild(engBtn);

  el.appendChild(bar);
}

function closeNsbEnginePopup() {
  if (_nsbEngPopup) { _nsbEngPopup.remove(); _nsbEngPopup = null; }
}

function openNsbEnginePopup(engBtn) {
  closeNsbEnginePopup();

  const popup = document.createElement('div');
  popup.className = 'nsb-eng-popup';
  popup.style.visibility = 'hidden';

  SEARCH_ENGINES.forEach(eng => {
    const opt = document.createElement('button');
    opt.className = 'nsb-eng-opt' + (eng.id === (S.navSearchEngine || 'google') ? ' active' : '');
    opt.appendChild(nsbEngineIcon(eng, 18));
    const label = document.createElement('span');
    label.textContent = eng.name;
    opt.appendChild(label);
    opt.addEventListener('click', e => {
      e.stopPropagation();
      S.navSearchEngine = eng.id;
      saveState();
      closeNsbEnginePopup();
      renderNavSearch();
      requestAnimationFrame(syncLayout);
    });
    popup.appendChild(opt);
  });

  _nsbEngPopup = popup;
  document.body.appendChild(popup);

  // Position after layout — visibility:hidden prevents flash
  const btnRect = engBtn.getBoundingClientRect();
  const popW = popup.offsetWidth;
  const popH = popup.offsetHeight;
  let left = btnRect.left;
  let top  = btnRect.bottom + 8;
  if (left + popW > window.innerWidth - 8) left = window.innerWidth - popW - 8;
  if (top  + popH > window.innerHeight - 8) top = btnRect.top - popH - 8;
  popup.style.left = left + 'px';
  popup.style.top  = top  + 'px';
  popup.style.visibility = '';

  const outsideClick = ev => {
    if (!popup.contains(ev.target) && ev.target !== engBtn) {
      closeNsbEnginePopup();
      document.removeEventListener('click', outsideClick, true);
    }
  };
  setTimeout(() => document.addEventListener('click', outsideClick, true), 0);
}


function activateColDropZones(sourceCol) {
  const ba = document.getElementById('boardsArea');
  const baRect = ba ? ba.getBoundingClientRect() : { top: 0, bottom: window.innerHeight };
  const bottomOffset = window.innerHeight - baRect.bottom;
  const colEls = document.querySelectorAll('.board-column');

  document.querySelectorAll('.col-drop-zone').forEach(z => {
    const c = parseInt(z.dataset.col);
    if (c === sourceCol) return;
    const colEl = colEls[c];
    if (!colEl) return;
    const colRect = colEl.getBoundingClientRect();
    // Start zone from the grid-cell (+ button) position, clamped to visible area
    const gridCell = colEl.querySelector('.grid-cell');
    const naturalTop = gridCell ? gridCell.getBoundingClientRect().top : colRect.bottom;
    const top = Math.max(baRect.top + 8, Math.min(naturalTop, baRect.bottom - 60));
    z.classList.add('active');
    z.style.cssText = `position:fixed;left:${colRect.left}px;width:${colRect.width}px;top:${top}px;bottom:${bottomOffset + 8}px;`;
  });
}
function deactivateColDropZones() {
  document.querySelectorAll('.col-drop-zone').forEach(z => {
    z.classList.remove('active', 'hover');
    z.style.cssText = '';
  });
}


function renderBoards() {
  const area = document.getElementById('boardsArea');
  area.innerHTML = '';

  const { BOARD_W, GAP, numCols } = getLayoutParams();

  const pageBoards = S.boards.filter(b => b.pageId === S.activePage);

  const container = document.createElement('div');
  container.className = 'boards-columns';
  container.style.setProperty('--board-w', BOARD_W + 'px');

  for (let c = 0; c < numCols; c++) {
    const col = document.createElement('div');
    col.className = 'board-column';
    const colBoards = pageBoards.filter(b => (b.col >= numCols ? numCols - 1 : b.col) === c).sort((a, b) => a.row - b.row);
    colBoards.forEach(board => {
      if (board.type === 'pomodoro') col.appendChild(buildPomodoroBoard(board));
      else if (board.type === 'notes') col.appendChild(buildNotesBoard(board));
      else if (board.type === 'search') col.appendChild(buildSearchBoard(board));
      else col.appendChild(buildBoard(board));
    });
    const dropZone = document.createElement('div');
    dropZone.className = 'col-drop-zone';
    dropZone.dataset.col = c;
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('hover'); });
    dropZone.addEventListener('dragleave', e => { if (!dropZone.contains(e.relatedTarget)) dropZone.classList.remove('hover'); });
    dropZone.addEventListener('drop', e => {
      e.preventDefault();
      dropZone.classList.remove('hover', 'active');
      if (_dragId) { moveBoardTo(_dragId, c, 9999); _dragId = null; }
    });
    col.appendChild(dropZone);
    col.appendChild(createCell(c, colBoards.length, true));

    // Gap drop: fires only in the spaces between boards (boards call stopPropagation)
    col.addEventListener('dragover', e => {
      if (!_dragId) return;
      e.preventDefault();
      const boards = [...col.querySelectorAll('.board')].filter(b => b.dataset.id !== _dragId);
      if (!boards.length) return;
      let best = null, bestBefore = true, bestDist = Infinity;
      boards.forEach(b => {
        const r = b.getBoundingClientRect();
        const dTop = Math.abs(e.clientY - r.top);
        const dBot = Math.abs(e.clientY - r.bottom);
        if (dTop < bestDist) { bestDist = dTop; best = b; bestBefore = true; }
        if (dBot < bestDist) { bestDist = dBot; best = b; bestBefore = false; }
      });
      document.querySelectorAll('.board.drop-before,.board.drop-after')
        .forEach(b => b.classList.remove('drop-before', 'drop-after'));
      if (best) {
        best.classList.add(bestBefore ? 'drop-before' : 'drop-after');
        _dropTarget = { id: best.dataset.id, before: bestBefore };
      }
    });
    col.addEventListener('dragleave', e => {
      if (col.contains(e.relatedTarget)) return;
      document.querySelectorAll('.board.drop-before,.board.drop-after')
        .forEach(b => b.classList.remove('drop-before', 'drop-after'));
      _dropTarget = null;
    });
    col.addEventListener('drop', e => {
      if (!_dragId) return;
      e.preventDefault();
      document.querySelectorAll('.board.drop-before,.board.drop-after')
        .forEach(b => b.classList.remove('drop-before', 'drop-after'));
      if (_dropTarget) insertBoardAt(_dragId, _dropTarget.id, _dropTarget.before);
      else moveBoardTo(_dragId, c, 9999);
      _dragId = null; _dropTarget = null;
    });

    container.appendChild(col);
  }

  area.appendChild(container);

  // Center the columns with an INTEGER margin so boards land on whole pixels
  // (sub-pixel positions trigger the backdrop-filter edge-halo). Done here
  // synchronously — not in syncLayout — so dragging never flashes boards left.
  const colsW = numCols * BOARD_W + (numCols - 1) * GAP;
  const offset = Math.max(0, Math.round((area.clientWidth - colsW) / 2));
  container.style.marginLeft = offset + 'px';

  updateFocusStats();
}

function createCell(col, row, canAdd) {
  const cell = document.createElement('div');
  cell.className = 'grid-cell' + (canAdd ? ' can-add' : '');
  const plus = document.createElement('span');
  plus.className = 'cell-plus';
  plus.textContent = '+';
  cell.appendChild(plus);
  if (canAdd) cell.addEventListener('click', () => addBoardAt(col, row));
  cell.addEventListener('dragover', e => { e.preventDefault(); cell.classList.add('drag-over'); });
  cell.addEventListener('dragleave', e => { if (!cell.contains(e.relatedTarget)) cell.classList.remove('drag-over'); });
  cell.addEventListener('drop', e => {
    e.preventDefault();
    cell.classList.remove('drag-over');
    if (_dragId) { moveBoardTo(_dragId, col, row); _dragId = null; }
  });
  return cell;
}

function buildBoard(board) {
  const el = document.createElement('div');
  el.className = 'board';
  el.dataset.id = board.id;
  const blurBg = document.createElement('div');
  blurBg.className = 'board-blur-bg';
  el.appendChild(blurBg);

  const hdr = document.createElement('div');
  hdr.className = 'board-header';

  el.addEventListener('dragover', e => {
    if (!_dragBkId) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.add('bk-drop-target');
  });
  el.addEventListener('dragleave', e => {
    if (!el.contains(e.relatedTarget)) el.classList.remove('bk-drop-target');
  });
  el.addEventListener('drop', e => {
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('bk-drop-target');
    if (_dragBkId && _dragBkId !== board.id) {
      const bk = S.bookmarks.find(b => b.id === _dragBkId);
      if (bk) {
        bk.boardId = board.id;
        bk.order = S.bookmarks.filter(b => b.boardId === board.id && b.id !== bk.id).length;
        saveState(); renderBoards();
      }
      _dragBkId = null;
    }
  });

  el.addEventListener('mousedown', e => {
    if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
    if (e.target.closest('.link-item') || e.target.closest('.add-link-row')) return;
    el.draggable = true;
  });
  el.addEventListener('dragstart', e => {
    _dragId = board.id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', board.id);
    setTimeout(() => el.classList.add('is-dragging'), 0);
    activateColDropZones(board.col);
  });
  el.addEventListener('dragend', () => {
    el.draggable = false;
    el.classList.remove('is-dragging');
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before', 'drop-after'));
    _dropTarget = null;
    deactivateColDropZones();
    if (_dragId) { _dragId = null; renderBoards(); }
  });

  const titleEl = document.createElement('span');
  titleEl.className = 'board-title';
  titleEl.textContent = board.name;
  if (board.syncFolderId && board.syncEnabled) {
    titleEl.classList.add('board-title--synced');
    titleEl.title = T('sync.badgeTitle');
  }
  titleEl.addEventListener('dblclick', () => startBoardRename(board.id, titleEl));

  const addLinkBtn = document.createElement('button');
  addLinkBtn.className = 'board-add-link-btn';
  addLinkBtn.textContent = '+';
  addLinkBtn.title = T('tip.addLink');
  addLinkBtn.setAttribute('data-tour', 'add-link');
  addLinkBtn.addEventListener('click', e => { e.stopPropagation(); showAddLinkInput(board.id, addLinkBtn); });

  const menuBtn = document.createElement('button');
  menuBtn.className = 'board-menu-btn';
  menuBtn.textContent = '···';
  menuBtn.addEventListener('click', e => { e.stopPropagation(); showBoardMenu(board.id, menuBtn); });

  hdr.appendChild(titleEl);
  hdr.appendChild(addLinkBtn);
  hdr.appendChild(menuBtn);
  el.appendChild(hdr);


  const boardBks = [...S.bookmarks]
    .filter(bk => bk.boardId === board.id)
    .sort((a, b) => a.order - b.order);
  const isExpanded = _expandedBoards.has(board.id);
  const maxShow = (S.hideExtraBookmarks && !isExpanded) ? (S.maxBookmarksShown || 5) : boardBks.length;
  boardBks.slice(0, maxShow).forEach(bk => el.appendChild(buildBookmark(bk)));
  if (S.hideExtraBookmarks) {
    if (boardBks.length > maxShow) {
      const moreBtn = document.createElement('button');
      moreBtn.className = 'bk-show-more-btn';
      moreBtn.textContent = T('board.more', { n: boardBks.length - maxShow });
      moreBtn.addEventListener('click', e => {
        e.stopPropagation();
        _expandedBoards.add(board.id);
        renderBoards();
      });
      el.appendChild(moreBtn);
    } else if (isExpanded && boardBks.length > (S.maxBookmarksShown || 5)) {
      const hideBtn = document.createElement('button');
      hideBtn.className = 'bk-show-more-btn';
      hideBtn.textContent = T('board.showLess');
      hideBtn.addEventListener('click', e => {
        e.stopPropagation();
        _expandedBoards.delete(board.id);
        renderBoards();
      });
      el.appendChild(hideBtn);
    }
  }

  el.addEventListener('dragover', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    const before = e.clientY < el.getBoundingClientRect().top + el.offsetHeight / 2;
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before', 'drop-after'));
    el.classList.add(before ? 'drop-before' : 'drop-after');
    _dropTarget = { id: board.id, before };
  });
  el.addEventListener('dragleave', e => {
    if (_dragId && !el.contains(e.relatedTarget))
      el.classList.remove('drop-before', 'drop-after');
  });
  el.addEventListener('drop', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('drop-before', 'drop-after');
    if (_dropTarget) { insertBoardAt(_dragId, _dropTarget.id, _dropTarget.before); }
    _dragId = null; _dropTarget = null;
  });

  applyBoardStyle(el, board);
  return el;
}

function buildBookmark(bk) {
  const el = document.createElement('a');
  el.className = 'link-item';
  el.href = bk.url;
  el.target = S.openInNewTab !== false ? '_blank' : '_self';
  const img = document.createElement('img');
  img.className = 'favicon';
  setFavicon(img, bk.url);

  const info = document.createElement('div');
  info.className = 'link-info';

  const title = document.createElement('span');
  title.className = 'link-title';
  title.textContent = bk.title;
  info.appendChild(title);

  if (bk.description) {
    const desc = document.createElement('span');
    desc.className = 'link-desc';
    desc.textContent = bk.description;
    info.appendChild(desc);
  }

  const menuBtn = document.createElement('button');
  menuBtn.className = 'link-menu-btn';
  menuBtn.textContent = '⋮';
  menuBtn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); showBookmarkMenu(bk.id, menuBtn); });

  el.addEventListener('contextmenu', e => { e.preventDefault(); e.stopPropagation(); showBookmarkMenu(bk.id, menuBtn, e.clientX, e.clientY); });

  el.addEventListener('mouseenter', () => {
    try {
      const origin = new URL(bk.url).origin;
      if (!document.querySelector(`link[data-pre="${origin}"]`)) {
        const l = document.createElement('link');
        l.rel = 'preconnect'; l.href = origin; l.dataset.pre = origin;
        document.head.appendChild(l);
      }
    } catch {}
  });
  el.addEventListener('mousedown', e => { if (e.target.closest('button')) return; el.draggable = true; });
  el.addEventListener('dragstart', e => {
    _dragBkId = bk.id;
    e.dataTransfer.effectAllowed = 'move';
    e.stopPropagation();
    setTimeout(() => el.classList.add('bk-dragging'), 0);
  });
  el.addEventListener('dragend', () => {
    el.draggable = false;
    el.classList.remove('bk-dragging');
    document.querySelectorAll('.board.bk-drop-target').forEach(b => b.classList.remove('bk-drop-target'));
    document.querySelectorAll('.link-item.bk-drop-before,.link-item.bk-drop-after')
      .forEach(b => b.classList.remove('bk-drop-before', 'bk-drop-after'));
    _bkDropTarget = null;
    if (_dragBkId) { _dragBkId = null; renderBoards(); }
  });

  el.addEventListener('dragover', e => {
    if (!_dragBkId || _dragBkId === bk.id) return;
    e.preventDefault(); e.stopPropagation();
    const before = e.clientY < el.getBoundingClientRect().top + el.offsetHeight / 2;
    document.querySelectorAll('.link-item.bk-drop-before,.link-item.bk-drop-after')
      .forEach(b => b.classList.remove('bk-drop-before', 'bk-drop-after'));
    el.classList.add(before ? 'bk-drop-before' : 'bk-drop-after');
    _bkDropTarget = { id: bk.id, before };
  });
  el.addEventListener('dragleave', e => {
    if (_dragBkId && !el.contains(e.relatedTarget))
      el.classList.remove('bk-drop-before', 'bk-drop-after');
  });
  el.addEventListener('drop', e => {
    if (!_dragBkId || _dragBkId === bk.id) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('bk-drop-before', 'bk-drop-after');
    if (_bkDropTarget) { reorderBookmark(_dragBkId, _bkDropTarget.id, _bkDropTarget.before); }
    _dragBkId = null; _bkDropTarget = null;
  });

  el.appendChild(img); el.appendChild(info); el.appendChild(menuBtn);
  return el;
}

// ── Bookmark popup helpers ──
function _placePopup(popup, anchor) {
  document.body.appendChild(popup);
  const r = anchor.getBoundingClientRect();
  popup.style.top  = Math.min(r.bottom + 6, window.innerHeight - 220) + 'px';
  popup.style.left = Math.min(r.left, window.innerWidth - 236) + 'px';
}

function _popupInput(parent, val, placeholder) {
  const inp = document.createElement('input');
  inp.className = 'add-link-input';
  inp.value = val || '';
  inp.placeholder = placeholder;
  parent.appendChild(inp);
  return inp;
}

function _popupBtns(parent, onCancel, onPrimary, primaryLabel) {
  const row = document.createElement('div');
  row.className = 'bk-popup-btns';
  const cancel = document.createElement('button');
  cancel.className = 'bk-popup-btn';
  cancel.textContent = T('common.cancel');
  cancel.addEventListener('click', onCancel);
  const primary = document.createElement('button');
  primary.className = 'bk-popup-btn bk-popup-btn-primary';
  primary.textContent = primaryLabel;
  primary.addEventListener('click', onPrimary);
  row.appendChild(cancel); row.appendChild(primary);
  parent.appendChild(row);
  return primary;
}

function _outsideClose(popup, exclude) {
  setTimeout(() => {
    const h = e => {
      if (!popup.contains(e.target) && (!exclude || !exclude.contains(e.target))) {
        popup.remove(); document.removeEventListener('click', h);
      }
    };
    document.addEventListener('click', h);
  }, 0);
}

// ── Add link (step 1 → step 2) ──
function showAddLinkInput(boardId, anchor) {
  document.querySelector('.bk-popup')?.remove();

  const popup = document.createElement('div');
  popup.className = 'bk-edit-popup bk-popup';

  const urlInput = _popupInput(popup, '', T('addlink.pasteUrl'));
  _popupBtns(popup, () => popup.remove(), proceed, T('addlink.add'));
  _placePopup(popup, anchor);
  urlInput.focus();

  function proceed() {
    const raw = urlInput.value.trim();
    if (!raw) { urlInput.focus(); return; }
    const url = /^https?:\/\//.test(raw) ? raw : 'https://' + raw;
    popup.remove();
    showAddLinkStep2(boardId, anchor, url);
  }
  urlInput.addEventListener('keydown', e => { if (e.key === 'Enter') proceed(); if (e.key === 'Escape') popup.remove(); });
  // No outside-click close here: an accidental click outside would discard the
  // typed URL. Dismiss via Esc or the Cancel button instead.
}

function showAddLinkStep2(boardId, anchor, url) {
  const popup = document.createElement('div');
  popup.className = 'bk-edit-popup bk-popup';

  const urlInput  = _popupInput(popup, url, T('popup.url'));
  // Pre-fill the name with the hostname; the user can rename it before saving.
  let autoName = url; try { autoName = new URL(url).hostname.replace('www.', ''); } catch {}
  const nameInput = _popupInput(popup, autoName, T('addlink.name'));
  const descInput = _popupInput(popup, '', T('addlink.descOptional'));

  function save() {
    const finalUrl = urlInput.value.trim();
    if (!finalUrl) return;
    const u = /^https?:\/\//.test(finalUrl) ? finalUrl : 'https://' + finalUrl;
    let auto = u; try { auto = new URL(u).hostname.replace('www.', ''); } catch {}
    addBookmark(boardId, u, nameInput.value.trim() || auto, descInput.value.trim() || undefined);
    popup.remove();
  }

  _popupBtns(popup, () => popup.remove(), save, T('addlink.add'));
  _placePopup(popup, anchor);
  nameInput.focus(); nameInput.select();

  [nameInput, descInput].forEach(inp =>
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') popup.remove(); })
  );
  urlInput.addEventListener('keydown', e => { if (e.key === 'Escape') popup.remove(); });
  // No outside-click close: don't discard a typed name/description by accident.
  // Dismiss via Esc or the Cancel button instead.
}

// ── Bookmark context menu ──
// Shared icon set for context menus — stroke uses currentColor so both themes work.
const MENU_ICONS = {
  open:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
  incognito: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>',
  edit:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>',
  rename:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>',
  openAll:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  trash:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
};

// Builds a context-menu shell with a consistent icon + label row style.
// Returns { menu, item, sep }. `icon` is one of MENU_ICONS (optional).
function createMenu() {
  const menu = document.createElement('div');
  menu.className = 'board-menu';
  function item(label, icon, cls, cb) {
    const el = document.createElement('div');
    el.className = 'board-menu-item' + (cls ? ' ' + cls : '');
    const ic = document.createElement('span');
    ic.className = 'board-menu-icon';
    if (icon) ic.innerHTML = icon;
    const lb = document.createElement('span');
    lb.className = 'board-menu-label';
    lb.textContent = label;
    el.appendChild(ic); el.appendChild(lb);
    el.addEventListener('click', () => { closeMenu(); cb(); });
    menu.appendChild(el);
  }
  function sep() {
    const el = document.createElement('div');
    el.className = 'board-menu-sep';
    menu.appendChild(el);
  }
  return { menu, item, sep };
}

function showBookmarkMenu(bkId, anchor, cx, cy) {
  closeMenu();
  const { menu, item, sep } = createMenu();
  _menu = menu;

  const bkForMenu = S.bookmarks.find(b => b.id === bkId);
  if (bkForMenu?.url) {
    item(T('menu.open'),           MENU_ICONS.open,      '', () => chrome.tabs.create({ url: bkForMenu.url, active: false }));
    item(T('menu.openIncognito'),  MENU_ICONS.incognito, '', () => chrome.windows.create({ url: bkForMenu.url, incognito: true }));
    sep();
  }
  item(T('menu.edit'),   MENU_ICONS.edit,  '',       () => showBookmarkEdit(bkId, anchor));
  item(T('menu.delete'), MENU_ICONS.trash, 'danger', () => deleteBookmark(bkId));

  document.body.appendChild(menu);

  const mw = menu.offsetWidth + 12;
  if (cx !== undefined && cy !== undefined) {
    menu.style.left = Math.min(cx, window.innerWidth - mw) + 'px';
    menu.style.top  = Math.min(cy, window.innerHeight - menu.offsetHeight - 8) + 'px';
  } else {
    const r = anchor.getBoundingClientRect();
    menu.style.left = Math.min(r.left, window.innerWidth - mw) + 'px';
    menu.style.top  = (r.bottom + 4) + 'px';
  }
  setTimeout(() => document.addEventListener('click', closeMenu, { once: true }), 0);
}

// ── Edit bookmark ──
function showBookmarkEdit(bkId, anchor) {
  document.querySelector('.bk-popup')?.remove();
  const bk = S.bookmarks.find(b => b.id === bkId);
  if (!bk) return;

  const popup = document.createElement('div');
  popup.className = 'bk-edit-popup bk-popup';

  const urlInput  = _popupInput(popup, bk.url,         T('popup.url'));
  const nameInput = _popupInput(popup, bk.title,        T('addlink.name'));
  const descInput = _popupInput(popup, bk.description,  T('addlink.descOptional'));

  function save() {
    const raw = urlInput.value.trim(); if (!raw) return;
    bk.url = /^https?:\/\//.test(raw) ? raw : 'https://' + raw;
    let auto = bk.url; try { auto = new URL(bk.url).hostname.replace('www.', ''); } catch {}
    bk.title = nameInput.value.trim() || auto;
    const d = descInput.value.trim();
    if (d) bk.description = d; else delete bk.description;
    saveState(); renderBoards(); popup.remove();
    const board = S.boards.find(b => b.id === bk.boardId);
    if (board?.syncFolderId && board.syncEnabled) syncPushUpdate(board, bk);
  }

  _popupBtns(popup, () => popup.remove(), save, T('common.save'));
  _placePopup(popup, anchor);
  nameInput.focus();

  [urlInput, nameInput, descInput].forEach(inp =>
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') popup.remove(); })
  );
  // No outside-click close: don't discard edits by an accidental click outside.
  // Dismiss via Esc or the Cancel button instead.
}

// ── Board menu ──
let _menu = null;
let _dragId = null, _dragBkId = null, _dropTarget = null, _bkDropTarget = null;
let _updateScrollThumb = null;
let _nsbEngPopup = null;

document.addEventListener('wheel', e => {
  if (!_dragId && !_dragBkId) return;
  const ba = document.getElementById('boardsArea');
  if (ba) { ba.scrollTop += e.deltaY; e.preventDefault(); }
}, { passive: false });
let _pomodoroState = {};
let _expandedBoards = new Set();
function closeMenu() { if (_menu) { _menu.remove(); _menu = null; } }

// Per-board customization was removed (caused backdrop-filter light-stripe
// artifacts with many customized boards). This now only clears any leftover
// inline styling so old boards fall back to the default theme appearance.
function applyBoardStyle(el, board) {
  const textVars = ['--board-text','--board-text-secondary','--board-text-dim','--board-text-hover','--board-hover-bg'];
  el.style.removeProperty('background'); el.style.removeProperty('backdrop-filter');
  el.style.removeProperty('-webkit-backdrop-filter'); el.style.removeProperty('border-color');
  textVars.forEach(v => el.style.removeProperty(v));
  el.classList.remove('board-custom-light');
}

function showBoardMenu(boardId, anchor) {
  closeMenu();
  const { menu, item, sep } = createMenu();

  const board = S.boards.find(b => b.id === boardId);
  const isCalOrPom = board && board.type === 'pomodoro';
  const isNotes = board && (board.type === 'notes' || board.type === 'search');
  let hasAction = false;
  if (!isCalOrPom) {
    item(T('menu.rename'), MENU_ICONS.rename, '', () => {
      const boardEl = document.querySelector(`.board[data-id="${boardId}"]`);
      if (boardEl) startBoardRename(boardId, boardEl.querySelector('.board-title'));
    });
    hasAction = true;
  }
  if (!isCalOrPom && !isNotes) {
    item(T('menu.openAll'), MENU_ICONS.openAll, '', () => {
      S.bookmarks.filter(bk => bk.boardId === boardId).forEach(bk => window.open(bk.url, '_blank'));
    });
    hasAction = true;
  }
  if (hasAction) sep();
  item(T('menu.deleteBoard'), MENU_ICONS.trash, 'danger', () => deleteBoard(boardId));

  document.body.appendChild(menu);
  _menu = menu;

  const r = anchor.getBoundingClientRect();
  menu.style.top = (r.bottom + 4) + 'px';
  menu.style.left = Math.min(r.left, window.innerWidth - menu.offsetWidth - 12) + 'px';

  setTimeout(() => document.addEventListener('click', closeMenu, { once: true }), 0);
}

function showPageMenu(pageId, x, y) {
  closeMenu();
  const { menu, item, sep } = createMenu();

  item(T('menu.rename'), MENU_ICONS.rename, '', () => {
    const tab = document.querySelector(`.page-tab[data-id="${pageId}"]`);
    if (tab) startPageRename(pageId, tab.querySelector('.page-tab-name'));
  });
  if (S.pages.length > 1) {
    sep();
    item(T('menu.delete'), MENU_ICONS.trash, 'danger', () => deletePage(pageId));
  }

  document.body.appendChild(menu);
  _menu = menu;

  menu.style.top = Math.min(y + 6, window.innerHeight - menu.offsetHeight - 8) + 'px';
  menu.style.left = Math.min(x, window.innerWidth - menu.offsetWidth - 12) + 'px';

  setTimeout(() => document.addEventListener('click', closeMenu, { once: true }), 0);
}

// ── Inline rename ──
function startBoardRename(boardId, titleEl, opts = {}) {
  const board = S.boards.find(b => b.id === boardId);
  if (!board || !titleEl || titleEl.tagName === 'INPUT') return;
  const isNew = !!opts.isNew;

  const input = document.createElement('input');
  input.className = 'board-title-input';
  // Stop Chrome autofill from previewing a saved value in the freshly-focused
  // field, which tinted the placeholder pale blue (:-internal-autofill-previewed).
  input.setAttribute('autocomplete', 'off');
  input.spellcheck = false;
  input.value = board.name;
  if (isNew) input.placeholder = T('board.new');
  titleEl.replaceWith(input);
  input.focus(); input.select();

  let done = false;
  function discard() {
    // A brand-new board left unnamed is dropped — protects against accidental
    // clicks on "+" and means an empty board never gets saved.
    done = true;
    S.boards = S.boards.filter(b => b.id !== boardId);
    saveState();
    renderBoards();
  }
  function commit() {
    if (done) return;
    const name = input.value.trim();
    if (isNew && !name) { discard(); return; }
    done = true;
    board.name = name || board.name;
    saveState();
    if (board.syncFolderId && board.syncEnabled) syncRenameFolder(board);
    const newEl = document.createElement('span');
    newEl.className = 'board-title';
    newEl.textContent = board.name;
    newEl.addEventListener('dblclick', () => startBoardRename(boardId, newEl));
    input.replaceWith(newEl);
  }
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') {
      input.removeEventListener('blur', commit);
      if (isNew) { discard(); return; }
      input.value = board.name; commit(); // restore original name
    }
  });
}

function startPageRename(pageId, nameEl) {
  const page = S.pages.find(p => p.id === pageId);
  if (!page) return;

  const input = document.createElement('input');
  input.style.cssText = 'background:none;border:none;border-bottom:1px solid rgba(255,255,255,0.3);color:inherit;font:inherit;outline:none;width:80px;padding:0;';
  input.value = page.name;
  nameEl.replaceWith(input);
  input.focus(); input.select();

  let done = false;
  function commit() {
    if (done) return; done = true;
    page.name = input.value.trim() || page.name;
    saveState();
    nameEl.textContent = page.name;
    input.replaceWith(nameEl);
  }
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { done = true; input.value = page.name; input.blur(); commit(); }
  });
}

// ── CRUD ──
function addPage() {
  const maxOrder = S.pages.length ? Math.max(...S.pages.map(p => p.order)) : -1;
  const page = { id: genId(), name: 'New Page', order: maxOrder + 1 };
  S.pages.push(page);
  S.activePage = page.id;
  track('page_created', { total_pages: S.pages.length });
  saveState(); renderAll();
  setTimeout(() => {
    const tab = document.querySelector(`.page-tab[data-id="${page.id}"]`);
    if (tab) startPageRename(page.id, tab.querySelector('.page-tab-name'));
  }, 50);
}

function deletePage(pageId) {
  if (S.pages.length <= 1) return;
  const boardIds = S.boards.filter(b => b.pageId === pageId).map(b => b.id);
  S.bookmarks = S.bookmarks.filter(bk => !boardIds.includes(bk.boardId));
  S.boards = S.boards.filter(b => b.pageId !== pageId);
  S.pages = S.pages.filter(p => p.id !== pageId);
  if (S.activePage === pageId) S.activePage = S.pages[0].id;
  saveState(); renderAll();
}

function switchPage(pageId) {
  if (S.activePage === pageId) return;
  S.activePage = pageId;
  saveState(); renderAll();
}

function addBoardAt(col, row) {
  const board = { id: genId(), pageId: S.activePage, name: '', col, row };
  S.boards.push(board);
  track('board_created', { total_boards: S.boards.length });
  trackOnce('mz-ga-activated', 'activated_user', { via: 'board' });
  // Not saved yet: persists only once the user types a name (see startBoardRename).
  renderBoards();
  const boardEl = document.querySelector(`.board[data-id="${board.id}"]`);
  if (boardEl) startBoardRename(board.id, boardEl.querySelector('.board-title'), { isNew: true });
}

function compactColumn(col) {
  S.boards
    .filter(b => b.pageId === S.activePage && b.col === col)
    .sort((a, b) => a.row - b.row)
    .forEach((b, i) => { b.row = i; });
}

function moveBoardTo(boardId, col, row) {
  const board = S.boards.find(b => b.id === boardId);
  if (!board) return;
  const sourceCol = board.col;
  board.col = col; board.row = row;
  compactColumn(col);
  if (col !== sourceCol) compactColumn(sourceCol);
  saveState(); renderBoards();
}

function insertBoardAt(draggedId, targetId, before) {
  if (draggedId === targetId) return;
  const dragged = S.boards.find(b => b.id === draggedId);
  const target  = S.boards.find(b => b.id === targetId);
  if (!dragged || !target) return;
  const sourceCol = dragged.col;
  const colBoards = S.boards
    .filter(b => b.pageId === S.activePage && b.col === target.col && b.id !== draggedId)
    .sort((a, b) => a.row - b.row);
  const idx = colBoards.findIndex(b => b.id === targetId);
  dragged.col = target.col;
  colBoards.splice(before ? idx : idx + 1, 0, dragged);
  colBoards.forEach((b, i) => { b.row = i; });
  if (sourceCol !== target.col) compactColumn(sourceCol);
  saveState(); renderBoards();
}

function reorderBookmark(draggedId, targetId, before) {
  if (draggedId === targetId) return;
  const dragged = S.bookmarks.find(b => b.id === draggedId);
  const target  = S.bookmarks.find(b => b.id === targetId);
  if (!dragged || !target) return;
  const prevBoardId = dragged.boardId;
  dragged.boardId = target.boardId;
  const boardBks = S.bookmarks
    .filter(b => b.boardId === target.boardId && b.id !== draggedId)
    .sort((a, b) => a.order - b.order);
  const idx = boardBks.findIndex(b => b.id === targetId);
  boardBks.splice(before ? idx : idx + 1, 0, dragged);
  boardBks.forEach((b, i) => { b.order = i; });
  saveState(); renderBoards();
  const destBoard = S.boards.find(b => b.id === target.boardId);
  if (destBoard?.syncFolderId && destBoard.syncEnabled) syncPushReorder(destBoard);
  if (prevBoardId !== target.boardId) {
    const srcBoard = S.boards.find(b => b.id === prevBoardId);
    if (srcBoard?.syncFolderId && srcBoard.syncEnabled) syncPushReorder(srcBoard);
  }
}

function findFreePosition() {
  const { numCols } = getLayoutParams();
  const occupied = new Set(S.boards.filter(b => b.pageId === S.activePage).map(b => `${b.col},${b.row}`));
  for (let row = 0; row < 100; row++) {
    for (let col = 0; col < numCols; col++) {
      if (!occupied.has(`${col},${row}`)) return { col, row };
    }
  }
  return { col: 0, row: 0 };
}

let _pomAudioCtx = null;
function playPomSound(type) {
  try {
    if (!_pomAudioCtx) _pomAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = _pomAudioCtx;
    // resume() must run synchronously inside user gesture; if context just started
    // currentTime is 0 so schedule slightly ahead to give the clock time to tick
    const needsWarmup = ctx.state !== 'running';
    ctx.resume();
    const t = ctx.currentTime + (needsWarmup ? 0.15 : 0);
    if (type === 'start') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(600, t);
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.start(t); osc.stop(t + 0.12);
    } else {
      [[523, 0], [659, 0.18], [784, 0.36]].forEach(([freq, delay]) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.connect(gain); gain.connect(ctx.destination);
        osc.frequency.setValueAtTime(freq, t + delay);
        gain.gain.setValueAtTime(0.35, t + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.6);
        osc.start(t + delay); osc.stop(t + delay + 0.6);
      });
    }
  } catch(e) {}
}

function addPomodoro() {
  const { col, row } = findFreePosition();
  const board = { id: genId(), pageId: S.activePage, name: 'Pomodoro', type: 'pomodoro', col, row };
  S.boards.push(board);
  saveState(); renderBoards();
}

const POM_PLAY  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="8,3 20,12 8,21"/></svg>`;
const POM_PAUSE = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`;
const POM_RESET = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><polyline points="3,3 3,8 8,8"/></svg>`;
const POM_SKIP  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="4,4 14,12 4,20" stroke="none"/><rect x="17" y="4" width="3" height="16" rx="1" stroke="none"/></svg>`;
const POM_GEAR  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;

function pomFmt(s) { return String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0'); }

function getPomSettings(board) {
  return Object.assign({ focus: 25, short: 5, long: 15, cycle: 4 }, board.pomSettings || {});
}

function savePomTimer(boardId) {
  const ps = _pomodoroState[boardId];
  if (!ps || !S.pomTimers) return;
  S.pomTimers[boardId] = {
    phase: ps.phase, sessions: ps.sessions,
    timeLeft: ps.timeLeft, running: ps.running,
    startedAt: ps.startedAt || null, startedTimeLeft: ps.startedTimeLeft != null ? ps.startedTimeLeft : null
  };
  saveState();
}

function getPomState(id, focusMins) {
  if (!_pomodoroState[id]) {
    const saved = S.pomTimers?.[id];
    if (saved) {
      let timeLeft = saved.timeLeft ?? ((focusMins || 25) * 60);
      // Recalculate from wall-clock if timer was running when page was closed
      if (saved.running && saved.startedAt && saved.startedTimeLeft != null) {
        const elapsed = Math.floor((Date.now() - saved.startedAt) / 1000);
        timeLeft = Math.max(0, saved.startedTimeLeft - elapsed);
      }
      let phase = saved.phase || 'work';
      let sessions = saved.sessions || 0;
      const wasRunning = !!(saved.running && timeLeft > 0);
      // Phase completed while away — record focus time and reset
      if (saved.running && timeLeft <= 0 && saved.phase === 'work') {
        if (!S.focusStats) S.focusStats = [];
        S.focusStats.push({ ts: Date.now(), mins: Math.round((saved.startedTimeLeft || (focusMins || 25) * 60) / 60) });
        sessions++; phase = 'work'; timeLeft = (focusMins || 25) * 60;
      } else if (saved.running && timeLeft <= 0) {
        phase = 'work'; timeLeft = (focusMins || 25) * 60;
      }
      _pomodoroState[id] = {
        phase, viewPhase: phase, timeLeft, running: wasRunning, sessions,
        interval: null,
        startedAt: wasRunning ? saved.startedAt : null,
        startedTimeLeft: wasRunning ? saved.startedTimeLeft : null
      };
    } else {
      _pomodoroState[id] = { phase:'work', viewPhase:'work', timeLeft:(focusMins||25)*60, running:false, sessions:0, interval:null, startedAt:null, startedTimeLeft:null };
    }
  } else if (!_pomodoroState[id].viewPhase) {
    _pomodoroState[id].viewPhase = _pomodoroState[id].phase;
  }
  return _pomodoroState[id];
}

function getFocusByDay(days) {
  const now = new Date();
  const result = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const start = d.getTime();
    let mins = (S.focusStats || []).filter(s => s.ts >= start && s.ts < start + 86400000).reduce((a, s) => a + s.mins, 0);
    if (i === 0) {
      // Add in-progress/paused work time to today
      Object.entries(_pomodoroState).forEach(([boardId, ps]) => {
        if (ps.phase === 'work') {
          const b = S.boards.find(b => b.id === boardId);
          if (b) mins += Math.floor(Math.max(0, getPomSettings(b).focus * 60 - ps.timeLeft) / 60);
        }
      });
    }
    result.push({ date: d, mins });
  }
  return result;
}

function getFocusByMonth(months) {
  const now = new Date();
  const result = [];
  for (let i = months - 1; i >= 0; i--) {
    const d   = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
    const mins = (S.focusStats || []).filter(s => s.ts >= d.getTime() && s.ts < end.getTime()).reduce((a, s) => a + s.mins, 0);
    result.push({ date: d, mins });
  }
  return result;
}

// ── Clock widget ──

function renderClockWidget() {
  const el = document.getElementById('clockWidget');
  if (!el) return;
  el.style.display = S.clockEnabled ? '' : 'none';
}

function tickClock() {
  const timeEl = document.getElementById('clockTime');
  const dateEl = document.getElementById('clockDate');
  if (!timeEl) return;

  const now = new Date();
  const loc = S.locale || {};
  const use12 = loc.timeFormat === '12h';

  let h = now.getHours(), m = now.getMinutes();
  if (use12) {
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    timeEl.innerHTML = `${h}:${String(m).padStart(2,'0')}<span class="clock-ampm">${ampm}</span>`;
  } else {
    timeEl.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
  }

  const DAY = T('clock.days');
  const MON = T('cal.monShort');
  const fmt = loc.dateFormat || 'DMY';
  const d = now.getDate(), mo = MON[now.getMonth()], wd = DAY[now.getDay()];
  let dateStr;
  if (fmt === 'MDY') dateStr = `${wd}, ${MON[now.getMonth()]} ${d}`;
  else               dateStr = `${wd}, ${d} ${mo}`;

  dateEl.textContent = dateStr;
}

let _clockInterval = null;
function startClock() {
  renderClockWidget();
  tickClock();
  const now = new Date();
  const msToNextMin = (60 - now.getSeconds()) * 1000 - now.getMilliseconds();
  setTimeout(() => {
    tickClock();
    _clockInterval = setInterval(tickClock, 60000);
  }, msToNextMin);
}

function updateFocusStats() {
  const el = document.getElementById('focusStats');
  if (!el) return;
  const hasPom = S.boards && S.boards.some(b => b.type === 'pomodoro');
  el.style.display = hasPom ? '' : 'none';
  if (!hasPom) return;

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const completedMins = (S.focusStats || []).filter(s => s.ts >= todayStart).reduce((a, s) => a + s.mins, 0);

  // Include in-progress AND paused work time (any elapsed seconds in current work phase)
  let inProgressSecs = 0;
  Object.entries(_pomodoroState).forEach(([boardId, ps]) => {
    if (ps.phase === 'work') {
      const b = S.boards.find(b => b.id === boardId);
      if (b) {
        const st = getPomSettings(b);
        inProgressSecs += Math.max(0, st.focus * 60 - ps.timeLeft);
      }
    }
  });

  const totalMins = Math.floor((completedMins * 60 + inProgressSecs) / 60);
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  let val;
  if (!totalMins)  val = '0m';
  else if (h)      val = `${h}h ${m}m`;
  else             val = `${m}m`;

  el.innerHTML = `<div class="focus-today-label">${T('focus.today')}</div><div class="focus-today-value">${val}</div>`;
}

function showFocusStatsPopup() {
  document.querySelector('.focus-stats-popup')?.remove();
  const popup = document.createElement('div');
  popup.className = 'focus-stats-popup';

  const hdr = document.createElement('div');
  hdr.className = 'focus-stats-popup-header';
  const title = document.createElement('span');
  title.className = 'focus-stats-popup-title';
  title.textContent = T('focus.stats');
  const closeBtn = document.createElement('button');
  closeBtn.className = 'focus-stats-popup-close';
  closeBtn.textContent = '×';
  closeBtn.addEventListener('click', () => popup.remove());
  hdr.appendChild(title); hdr.appendChild(closeBtn);
  popup.appendChild(hdr);

  const toggle = document.createElement('div');
  toggle.className = 'focus-stats-toggle';
  const weekBtn  = document.createElement('button');
  weekBtn.className  = 'focus-stats-toggle-btn active';
  weekBtn.textContent = T('focus.week');
  const monthBtn = document.createElement('button');
  monthBtn.className = 'focus-stats-toggle-btn';
  monthBtn.textContent = T('focus.months');
  toggle.appendChild(weekBtn); toggle.appendChild(monthBtn);
  popup.appendChild(toggle);

  const chartEl = document.createElement('div');
  chartEl.className = 'focus-chart';
  popup.appendChild(chartEl);

  let view = 'week';
  const DAY_SHORT = T('cal.dayShort');
  const MON_SHORT = T('cal.monShort');
  const MAX_BAR_H = 78;
  const now = new Date();

  function renderChart() {
    chartEl.innerHTML = '';
    const data = view === 'week' ? getFocusByDay(7) : getFocusByMonth(6);
    const totalMins = data.reduce((a, d) => a + d.mins, 0);

    if (!totalMins) {
      const empty = document.createElement('div');
      empty.className = 'focus-chart-empty';
      empty.textContent = T('focus.none');
      chartEl.appendChild(empty);
      return;
    }

    const maxMins = Math.max(...data.map(d => d.mins));
    data.forEach((item, i) => {
      const isNow = view === 'week'
        ? i === data.length - 1
        : item.date.getMonth() === now.getMonth() && item.date.getFullYear() === now.getFullYear();

      const col = document.createElement('div');
      col.className = 'focus-chart-col' + (isNow ? ' today' : '');

      const topLabel = document.createElement('div');
      topLabel.className = 'focus-chart-top-label';
      if (item.mins) {
        const h = Math.floor(item.mins / 60);
        topLabel.textContent = h ? `${h}h` : `${item.mins}m`;
      }

      const track = document.createElement('div');
      track.className = 'focus-chart-track';
      const bar = document.createElement('div');
      bar.className = 'focus-chart-bar';
      bar.style.height = (item.mins ? Math.max(3, Math.round((item.mins / maxMins) * MAX_BAR_H)) : 0) + 'px';
      track.appendChild(bar);

      const label = document.createElement('div');
      label.className = 'focus-chart-label';
      label.textContent = view === 'week' ? DAY_SHORT[item.date.getDay()] : MON_SHORT[item.date.getMonth()];

      col.appendChild(topLabel); col.appendChild(track); col.appendChild(label);
      chartEl.appendChild(col);
    });
  }

  weekBtn.addEventListener('click', () => {
    view = 'week'; weekBtn.classList.add('active'); monthBtn.classList.remove('active'); renderChart();
  });
  monthBtn.addEventListener('click', () => {
    view = 'month'; monthBtn.classList.add('active'); weekBtn.classList.remove('active'); renderChart();
  });

  renderChart();
  // Keep chart up-to-date while popup is open
  const chartRefresh = setInterval(() => { if (document.contains(popup)) renderChart(); else clearInterval(chartRefresh); }, 5000);
  closeBtn.addEventListener('click', () => clearInterval(chartRefresh));

  document.body.appendChild(popup);

  const statsEl = document.getElementById('focusStats');
  const rect = statsEl.getBoundingClientRect();
  popup.style.top   = (rect.bottom + 8) + 'px';
  popup.style.right = (window.innerWidth - rect.right) + 'px';

  _outsideClose(popup, document.getElementById('focusStats'));
}

function showPomodoroSettings(boardId, anchor) {
  document.querySelector('.pom-settings-popup')?.remove();
  const board = S.boards.find(b => b.id === boardId);
  if (!board) return;
  const s = getPomSettings(board);
  const popup = document.createElement('div');
  popup.className = 'bk-edit-popup pom-settings-popup';

  function row(label, key, val) {
    const wrap = document.createElement('div');
    wrap.className = 'pom-setting-row';
    const lbl = document.createElement('span');
    lbl.className = 'pom-setting-label';
    lbl.textContent = label;
    const inp = document.createElement('input');
    inp.type = 'number'; inp.min = 1; inp.max = 120;
    inp.className = 'add-link-input pom-setting-input';
    inp.value = val; inp.dataset.key = key;
    wrap.appendChild(lbl); wrap.appendChild(inp);
    popup.appendChild(wrap);
    return inp;
  }

  const focusInp = row(T('pom.focusMin'),  'focus', s.focus);
  const shortInp = row(T('pom.shortMin'),  'short', s.short);
  const longInp  = row(T('pom.longMin'),   'long',  s.long);
  const cycleInp = row(T('pom.longAfter'), 'cycle', s.cycle);

  _popupBtns(popup, () => popup.remove(), () => {
    const newS = {
      focus: Math.max(1, parseInt(focusInp.value)||25),
      short: Math.max(1, parseInt(shortInp.value)||5),
      long:  Math.max(1, parseInt(longInp.value)||15),
      cycle: Math.max(1, parseInt(cycleInp.value)||4)
    };
    board.pomSettings = newS;
    const ps = _pomodoroState[boardId];
    if (ps && !ps.running) {
      // Not running — reset to new focus time immediately
      ps.phase = 'work'; ps.viewPhase = 'work'; ps.timeLeft = newS.focus * 60;
    }
    // If running — current slot finishes with old duration, new settings apply next cycle
    saveState(); renderBoards();
    popup.remove();
  }, T('common.save'));

  _placePopup(popup, anchor);
  focusInp.focus(); focusInp.select();
  _outsideClose(popup);
}

function buildPomodoroBoard(board) {
  const el = document.createElement('div');
  el.className = 'board';
  el.dataset.id = board.id;
  const blurBg = document.createElement('div');
  blurBg.className = 'board-blur-bg';
  el.appendChild(blurBg);

  const settings = getPomSettings(board);
  const phases = {
    work:  { label: T('pom.focus'), mins: settings.focus },
    short: { label: T('pom.short'), mins: settings.short },
    long:  { label: T('pom.long'),  mins: settings.long  }
  };
  const ps = getPomState(board.id, settings.focus);

  // ── Header ──
  const hdr = document.createElement('div');
  hdr.className = 'board-header';
  const titleEl = document.createElement('span');
  titleEl.className = 'board-title';
  titleEl.textContent = board.name || T('pom.title');
  const settingsBtn = document.createElement('button');
  settingsBtn.className = 'board-add-link-btn';
  settingsBtn.innerHTML = POM_GEAR;
  settingsBtn.title = T('side.settings');
  settingsBtn.addEventListener('click', e => { e.stopPropagation(); showPomodoroSettings(board.id, settingsBtn); });
  const menuBtn = document.createElement('button');
  menuBtn.className = 'board-menu-btn';
  menuBtn.textContent = '···';
  menuBtn.addEventListener('click', e => { e.stopPropagation(); showBoardMenu(board.id, menuBtn); });
  hdr.appendChild(titleEl); hdr.appendChild(settingsBtn); hdr.appendChild(menuBtn);
  el.appendChild(hdr);

  // ── Phase tabs ──
  const phasesEl = document.createElement('div');
  phasesEl.className = 'pom-phases';
  Object.entries(phases).forEach(([key, ph]) => {
    const btn = document.createElement('button');
    btn.className = 'pom-phase-btn' + (ps.viewPhase === key ? ' active' : '');
    btn.textContent = ph.label;
    btn.addEventListener('click', e => {
      e.stopPropagation();
      ps.viewPhase = key;
      renderBoards();
    });
    phasesEl.appendChild(btn);
  });
  el.appendChild(phasesEl);

  // ── Timer ──
  const timerEl = document.createElement('div');
  timerEl.className = 'pom-timer';
  // Show viewPhase time: if viewing a different phase than running, show that phase's full duration
  timerEl.textContent = pomFmt(ps.viewPhase === ps.phase ? ps.timeLeft : phases[ps.viewPhase].mins * 60);
  el.appendChild(timerEl);

  // ── Session dots ──
  const cycle = settings.cycle;
  const dotsEl = document.createElement('div');
  dotsEl.className = 'pom-dots';
  for (let i = 0; i < cycle; i++) {
    const dot = document.createElement('span');
    dot.className = 'pom-dot' + (i < ps.sessions % cycle ? ' active' : '');
    dotsEl.appendChild(dot);
  }
  el.appendChild(dotsEl);

  // ── Controls ──
  const ctrlEl = document.createElement('div');
  ctrlEl.className = 'pom-controls';

  const resetBtn = document.createElement('button');
  resetBtn.className = 'pom-ctrl-btn'; resetBtn.innerHTML = POM_RESET; resetBtn.title = T('tip.reset');

  const playBtn = document.createElement('button');
  playBtn.className = 'pom-ctrl-btn pom-play-btn';
  playBtn.innerHTML = ps.running ? POM_PAUSE : POM_PLAY;

  const skipBtn = document.createElement('button');
  skipBtn.className = 'pom-ctrl-btn'; skipBtn.innerHTML = POM_SKIP; skipBtn.title = T('tip.skip');

  function tick() {
    // Wall-clock based: accurate even when tab was inactive or page reloaded
    if (ps.startedAt != null) {
      const elapsed = Math.floor((Date.now() - ps.startedAt) / 1000);
      ps.timeLeft = Math.max(0, ps.startedTimeLeft - elapsed);
    } else {
      ps.timeLeft = Math.max(0, ps.timeLeft - 1);
    }
    if (ps.viewPhase === ps.phase) {
      const t = document.querySelector(`.board[data-id="${board.id}"] .pom-timer`);
      if (t) t.textContent = pomFmt(ps.timeLeft);
    }
    updateFocusStats();
    if (ps.timeLeft <= 0) {
      clearInterval(ps.interval); ps.interval = null; ps.running = false;
      ps.startedAt = null; ps.startedTimeLeft = null;
      playPomSound('end');
      if (ps.phase === 'work') {
        S.focusStats.push({ ts: Date.now(), mins: settings.focus });
        ps.sessions++;
        ps.phase = ps.sessions % cycle === 0 ? 'long' : 'short';
      } else ps.phase = 'work';
      ps.viewPhase = ps.phase;
      ps.timeLeft = phases[ps.phase].mins * 60;
      savePomTimer(board.id);
      renderBoards();
    }
  }

  // Auto-restart interval if timer was running when page was closed/refreshed
  if (ps.running && !ps.interval) {
    ps.interval = setInterval(tick, 1000);
  }

  playBtn.addEventListener('click', e => {
    e.stopPropagation();
    if (ps.viewPhase !== ps.phase) {
      if (ps.interval) { clearInterval(ps.interval); ps.interval = null; }
      ps.phase = ps.viewPhase;
      ps.timeLeft = phases[ps.phase].mins * 60;
      ps.running = true;
      ps.startedAt = Date.now(); ps.startedTimeLeft = ps.timeLeft;
      ps.interval = setInterval(tick, 1000);
      playBtn.innerHTML = POM_PAUSE;
      playPomSound('start');
    } else if (ps.running) {
      clearInterval(ps.interval); ps.interval = null; ps.running = false;
      ps.startedAt = null; ps.startedTimeLeft = null;
      playBtn.innerHTML = POM_PLAY;
      updateFocusStats();
    } else {
      ps.running = true;
      ps.startedAt = Date.now(); ps.startedTimeLeft = ps.timeLeft;
      ps.interval = setInterval(tick, 1000);
      playBtn.innerHTML = POM_PAUSE;
      playPomSound('start');
    }
    if (ps.running) track('pomodoro_started', { phase: ps.phase });
    savePomTimer(board.id);
  });

  resetBtn.addEventListener('click', e => {
    e.stopPropagation();
    if (ps.interval) { clearInterval(ps.interval); ps.interval = null; }

    // Сохраняем прошедшее рабочее время в статистику перед сбросом
    if (ps.phase === 'work') {
      const fullSecs = settings.focus * 60;
      const elapsedSecs = fullSecs - ps.timeLeft;
      if (elapsedSecs >= 60) {
        if (!S.focusStats) S.focusStats = [];
        S.focusStats.push({ ts: Date.now(), mins: Math.floor(elapsedSecs / 60) });
      }
    }

    ps.running = false; ps.startedAt = null; ps.startedTimeLeft = null;
    ps.phase = ps.viewPhase;
    ps.timeLeft = phases[ps.viewPhase].mins * 60;
    timerEl.textContent = pomFmt(ps.timeLeft);
    playBtn.innerHTML = POM_PLAY;
    savePomTimer(board.id);
    updateFocusStats();
  });

  skipBtn.addEventListener('click', e => {
    e.stopPropagation();
    if (ps.interval) { clearInterval(ps.interval); ps.interval = null; }
    ps.startedAt = null; ps.startedTimeLeft = null;
    if (ps.phase === 'work') {
      const elapsedMins = Math.max(1, Math.round((settings.focus * 60 - ps.timeLeft) / 60));
      S.focusStats.push({ ts: Date.now(), mins: elapsedMins });
      ps.sessions++;
      ps.phase = ps.sessions % cycle === 0 ? 'long' : 'short';
    } else ps.phase = 'work';
    ps.viewPhase = ps.phase;
    ps.timeLeft = phases[ps.phase].mins * 60; ps.running = false;
    savePomTimer(board.id);
    renderBoards();
  });

  ctrlEl.appendChild(resetBtn); ctrlEl.appendChild(playBtn); ctrlEl.appendChild(skipBtn);
  el.appendChild(ctrlEl);

  // ── Drag ──
  el.addEventListener('mousedown', e => { if (e.target.closest('button')) return; el.draggable = true; });
  el.addEventListener('dragstart', e => {
    _dragId = board.id; e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', board.id);
    setTimeout(() => el.classList.add('is-dragging'), 0);
    activateColDropZones(board.col);
  });
  el.addEventListener('dragend', () => {
    el.draggable = false; el.classList.remove('is-dragging');
    document.querySelectorAll('.board.drop-before,.board.drop-after').forEach(b => b.classList.remove('drop-before','drop-after'));
    _dropTarget = null; deactivateColDropZones(); if (_dragId) { _dragId = null; renderBoards(); }
  });
  applyBoardStyle(el, board);
  el.addEventListener('dragover', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    const before = e.clientY < el.getBoundingClientRect().top + el.offsetHeight / 2;
    document.querySelectorAll('.board.drop-before,.board.drop-after').forEach(b => b.classList.remove('drop-before','drop-after'));
    el.classList.add(before ? 'drop-before' : 'drop-after');
    _dropTarget = { id: board.id, before };
  });
  el.addEventListener('dragleave', e => {
    if (_dragId && !el.contains(e.relatedTarget)) el.classList.remove('drop-before','drop-after');
  });
  el.addEventListener('drop', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('drop-before','drop-after');
    if (_dropTarget) insertBoardAt(_dragId, _dropTarget.id, _dropTarget.before);
    _dragId = null; _dropTarget = null;
  });

  return el;
}

function addBoard() {
  const { col, row } = findFreePosition();
  addBoardAt(col, row);
}

const SEARCH_ENGINES = [
  { id: 'default', name: T('search.defaultEngine'), url: null,                                   domain: null             },
  { id: 'google',  name: 'Google',          url: 'https://www.google.com/search?q=',             domain: 'google.com'     },
  { id: 'yandex',  name: 'Yandex',          url: 'https://yandex.ru/search/?text=',              domain: 'yandex.ru'      },
  { id: 'bing',    name: 'Bing',            url: 'https://www.bing.com/search?q=',               domain: 'bing.com'       },
  { id: 'ddg',     name: 'DuckDuckGo',      url: 'https://duckduckgo.com/?q=',                   domain: 'duckduckgo.com' },
  { id: 'youtube', name: 'YouTube',         url: 'https://www.youtube.com/results?search_query=',domain: 'youtube.com'    },
  { id: 'ecosia',  name: 'Ecosia',          url: 'https://www.ecosia.org/search?q=',             domain: 'ecosia.org'     },
];

function nsbFaviconUrl(domain) {
  return `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
}

// Returns img or span element for engine icon
function nsbEngineIcon(eng, size) {
  size = size || 16;
  if (eng.id === 'default') {
    const wrap = document.createElement('span');
    wrap.style.cssText = `width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center;flex-shrink:0;opacity:0.6;`;
    wrap.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`;
    return wrap;
  }
  const img = document.createElement('img');
  img.src = nsbFaviconUrl(eng.domain);
  img.width = size;
  img.height = size;
  img.style.cssText = `border-radius:${size <= 16 ? 3 : 4}px;display:block;flex-shrink:0;`;
  return img;
}

function nsbDoSearch(query) {
  const eng = SEARCH_ENGINES.find(e => e.id === (S.navSearchEngine || 'google')) || SEARCH_ENGINES[1];
  track('search_used', { source: 'navbar', engine: eng.id });
  if (eng.id === 'default') {
    chrome.search.query({ text: query, disposition: 'NEW_TAB' });
  } else {
    chrome.tabs.create({ url: eng.url + encodeURIComponent(query) });
  }
}

function buildSearchBoard(board) {
  const el = document.createElement('div');
  el.className = 'board';
  el.dataset.id = board.id;
  const blurBg = document.createElement('div');
  blurBg.className = 'board-blur-bg';
  el.appendChild(blurBg);

  const hdr = document.createElement('div');
  hdr.className = 'board-header';
  const title = document.createElement('span');
  title.className = 'board-title';
  title.textContent = board.name;
  title.addEventListener('dblclick', () => startBoardRename(board.id, title));
  const menuBtn = document.createElement('button');
  menuBtn.className = 'board-menu-btn';
  menuBtn.textContent = '···';
  menuBtn.addEventListener('click', e => { e.stopPropagation(); showBoardMenu(board.id, menuBtn); });
  hdr.appendChild(title);
  hdr.appendChild(menuBtn);
  el.appendChild(hdr);

  // Search input row
  const inputWrap = document.createElement('div');
  inputWrap.className = 'search-widget-wrap';
  inputWrap.innerHTML = `<svg class="search-widget-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`;
  const input = document.createElement('input');
  input.className = 'search-widget-input';
  input.type = 'text';
  input.placeholder = T('search.widgetPlaceholder');
  input.addEventListener('mousedown', e => e.stopPropagation());
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && input.value.trim()) {
      const engine = SEARCH_ENGINES.find(en => en.id === (board.searchEngine || 'google')) || SEARCH_ENGINES[1];
      track('search_used', { source: 'widget', engine: engine.id });
      chrome.tabs.create({ url: engine.url + encodeURIComponent(input.value.trim()) });
      input.value = '';
    }
  });
  inputWrap.appendChild(input);
  el.appendChild(inputWrap);

  // Engine selector (no 'default' option — board widget uses explicit URLs)
  const engines = document.createElement('div');
  engines.className = 'search-widget-engines';
  SEARCH_ENGINES.filter(e => e.id !== 'default').forEach(eng => {
    const btn = document.createElement('button');
    btn.className = 'search-engine-btn' + (eng.id === (board.searchEngine || 'google') ? ' active' : '');
    btn.textContent = eng.name;
    btn.title = eng.name;
    btn.addEventListener('click', e => {
      e.stopPropagation();
      board.searchEngine = eng.id;
      saveState();
      engines.querySelectorAll('.search-engine-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
    engines.appendChild(btn);
  });
  el.appendChild(engines);

  // Drag
  el.addEventListener('mousedown', e => {
    if (e.target.closest('button') || e.target.tagName === 'INPUT') return;
    el.draggable = true;
  });
  el.addEventListener('dragstart', e => {
    _dragId = board.id; e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', board.id);
    setTimeout(() => el.classList.add('is-dragging'), 0);
    activateColDropZones(board.col);
  });
  el.addEventListener('dragend', () => {
    el.draggable = false; el.classList.remove('is-dragging');
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before','drop-after'));
    _dropTarget = null; deactivateColDropZones();
    if (_dragId) { _dragId = null; renderBoards(); }
  });
  el.addEventListener('dragover', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    const before = e.clientY < el.getBoundingClientRect().top + el.offsetHeight / 2;
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before','drop-after'));
    el.classList.add(before ? 'drop-before' : 'drop-after');
    _dropTarget = { id: board.id, before };
  });
  el.addEventListener('dragleave', e => {
    if (_dragId && !el.contains(e.relatedTarget)) el.classList.remove('drop-before','drop-after');
  });
  el.addEventListener('drop', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('drop-before','drop-after');
    if (_dropTarget) insertBoardAt(_dragId, _dropTarget.id, _dropTarget.before);
    _dragId = null; _dropTarget = null;
  });

  applyBoardStyle(el, board);
  return el;
}

function addNotes() {
  const { col, row } = findFreePosition();
  const board = { id: genId(), pageId: S.activePage, name: 'Notes', type: 'notes', col, row, noteContent: '' };
  S.boards.push(board);
  saveState(); renderBoards();
  setTimeout(() => {
    const el = document.querySelector(`.board[data-id="${board.id}"] .notes-textarea`);
    if (el) el.focus();
  }, 60);
}

function buildNotesBoard(board) {
  const el = document.createElement('div');
  el.className = 'board';
  el.dataset.id = board.id;
  const blurBg = document.createElement('div');
  blurBg.className = 'board-blur-bg';
  el.appendChild(blurBg);

  const hdr = document.createElement('div');
  hdr.className = 'board-header';

  const title = document.createElement('span');
  title.className = 'board-title';
  title.textContent = board.name;
  title.addEventListener('dblclick', () => startBoardRename(board.id, title));

  const menuBtn = document.createElement('button');
  menuBtn.className = 'board-menu-btn';
  menuBtn.textContent = '···';
  menuBtn.addEventListener('click', e => { e.stopPropagation(); showBoardMenu(board.id, menuBtn); });

  hdr.appendChild(title);
  hdr.appendChild(menuBtn);
  el.appendChild(hdr);

  const textarea = document.createElement('textarea');
  textarea.className = 'notes-textarea';
  textarea.placeholder = T('notes.placeholder');
  textarea.value = board.noteContent || '';
  textarea.spellcheck = false;
  if (board.noteHeight) textarea.style.height = board.noteHeight + 'px';

  let _saveTimer;
  textarea.addEventListener('input', () => {
    board.noteContent = textarea.value;
    clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => saveState(), 600);
  });
  textarea.addEventListener('mousedown', e => e.stopPropagation());
  textarea.addEventListener('dragstart', e => e.preventDefault());

  el.appendChild(textarea);

  const resizeHandle = document.createElement('div');
  resizeHandle.className = 'notes-resize-handle';
  resizeHandle.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="10" cy="6" r="1.2" fill="currentColor"/>
    <circle cx="10" cy="10" r="1.2" fill="currentColor"/>
    <circle cx="6" cy="10" r="1.2" fill="currentColor"/>
  </svg>`;
  resizeHandle.addEventListener('mousedown', e => {
    e.preventDefault(); e.stopPropagation();
    const startY = e.clientY;
    const startH = textarea.offsetHeight;
    function onMove(ev) {
      const h = Math.max(60, startH + (ev.clientY - startY));
      textarea.style.height = h + 'px';
      board.noteHeight = h;
    }
    function onUp() {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      saveState();
    }
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
  el.appendChild(resizeHandle);

  el.addEventListener('mousedown', e => {
    if (e.target.closest('button') || e.target.tagName === 'TEXTAREA') return;
    el.draggable = true;
  });
  el.addEventListener('dragstart', e => {
    _dragId = board.id; e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', board.id);
    setTimeout(() => el.classList.add('is-dragging'), 0);
    activateColDropZones(board.col);
  });
  el.addEventListener('dragend', () => {
    el.draggable = false; el.classList.remove('is-dragging');
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before','drop-after'));
    _dropTarget = null; deactivateColDropZones();
    if (_dragId) { _dragId = null; document.activeElement?.blur(); renderBoards(); }
  });
  el.addEventListener('dragover', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    const before = e.clientY < el.getBoundingClientRect().top + el.offsetHeight / 2;
    document.querySelectorAll('.board.drop-before,.board.drop-after')
      .forEach(b => b.classList.remove('drop-before','drop-after'));
    el.classList.add(before ? 'drop-before' : 'drop-after');
    _dropTarget = { id: board.id, before };
  });
  el.addEventListener('dragleave', e => {
    if (_dragId && !el.contains(e.relatedTarget)) el.classList.remove('drop-before','drop-after');
  });
  el.addEventListener('drop', e => {
    if (!_dragId || _dragId === board.id) return;
    e.preventDefault(); e.stopPropagation();
    el.classList.remove('drop-before','drop-after');
    if (_dropTarget) insertBoardAt(_dragId, _dropTarget.id, _dropTarget.before);
    _dragId = null; _dropTarget = null;
  });

  applyBoardStyle(el, board);
  return el;
}

function deleteBoard(boardId) {
  const board = S.boards.find(b => b.id === boardId);
  if (!board) return;
  if (_pomodoroState[boardId]?.interval) { clearInterval(_pomodoroState[boardId].interval); }
  delete _pomodoroState[boardId];
  const isWidget = board.type === 'pomodoro' || board.type === 'notes' || board.type === 'search';
  const hasLinks = S.bookmarks.some(bk => bk.boardId === boardId);
  if (!isWidget && hasLinks) {
    const now = Date.now();
    S.trash.boards.push({ ...board, deletedAt: now });
    S.bookmarks.filter(bk => bk.boardId === boardId).forEach(bk =>
      S.trash.bookmarks.push({ ...bk, deletedAt: now })
    );
  }
  S.boards = S.boards.filter(b => b.id !== boardId);
  S.bookmarks = S.bookmarks.filter(bk => bk.boardId !== boardId);
  saveState(); renderBoards();
  if (board.syncFolderId && board.syncEnabled) syncRemoveFolder(board);
}

function addBookmark(boardId, url, title, description) {
  const board = S.boards.find(b => b.id === boardId);
  const count = S.bookmarks.filter(bk => bk.boardId === boardId).length;
  const bk = { id: genId(), boardId, url, title, order: count };
  if (description) bk.description = description;
  S.bookmarks.push(bk);
  track('bookmark_added', { total_bookmarks: S.bookmarks.length });
  trackOnce('mz-ga-activated', 'activated_user', { via: 'bookmark' });
  saveState(); renderBoards();
  if (board?.syncFolderId && board.syncEnabled) syncPushCreate(board, bk);
}

function deleteBookmark(bkId) {
  const bk = S.bookmarks.find(b => b.id === bkId);
  if (!bk) return;
  const board = S.boards.find(b => b.id === bk.boardId);
  S.trash.bookmarks.push({ ...bk, deletedAt: Date.now() });
  S.bookmarks = S.bookmarks.filter(b => b.id !== bkId);
  saveState(); renderBoards();
  if (board?.syncFolderId && board.syncEnabled) syncPushRemove(board, bk);
}


document.getElementById('addBoardFab').addEventListener('click', addBoard);
document.getElementById('focusStats').addEventListener('click', () => {
  const existing = document.querySelector('.focus-stats-popup');
  if (existing) existing.remove();
  else showFocusStatsPopup();
});

const sidebar = document.getElementById('sidebar');
function openSidebar() { sidebar.classList.add('is-open'); }
function closeSidebar() { sidebar.classList.remove('is-open'); }

document.getElementById('menuSideBtn').addEventListener('click', e => {
  e.stopPropagation();
  sidebar.classList.contains('is-open') ? closeSidebar() : openSidebar();
});
document.addEventListener('click', e => {
  if (sidebar.classList.contains('is-open') && !sidebar.contains(e.target)) closeSidebar();
});

document.getElementById('searchSideBtn').addEventListener('click', () => { closeSidebar(); openSearch(); });
document.getElementById('mpWidgets').addEventListener('click', e => {
  e.stopPropagation();
  const gallery = document.getElementById('widgetGallery');
  const opening = !gallery.classList.contains('open');
  gallery.classList.toggle('open', opening);
});
document.getElementById('mpImport').addEventListener('click', () => {
  closeSidebar(); openImportModal();
});
document.getElementById('mpExport').addEventListener('click', () => {
  closeSidebar(); exportBookmarks();
});
document.getElementById('mpWallpaper').addEventListener('click', (e) => {
  closeSidebar();
  showWallpaperMenu(e.currentTarget);
});
document.getElementById('wallpaperFileInput').addEventListener('change', e => {
  const file = e.target.files && e.target.files[0];
  setWallpaperFromFile(file);
  e.target.value = ''; // allow re-selecting the same file later
});
document.getElementById('wallpaperVideoInput').addEventListener('change', async e => {
  const file = e.target.files && e.target.files[0];
  e.target.value = '';
  if (file) await setWallpaperFromVideoFile(file);
});

function showWallpaperMenu(anchor) {
  closeMenu();
  const { menu, item, sep } = createMenu();
  _menu = menu;
  item('Set image wallpaper', null, '', () => document.getElementById('wallpaperFileInput').click());
  item('Set video wallpaper', null, '', () => document.getElementById('wallpaperVideoInput').click());
  if (S.wallpaperType) {
    sep();
    item('Remove wallpaper', MENU_ICONS.trash, 'danger', () => clearWallpaper());
  }
  document.body.appendChild(menu);
  const rect = anchor.getBoundingClientRect();
  menu.style.position = 'fixed';
  menu.style.visibility = 'hidden';
  const menuW = menu.offsetWidth;
  const menuH = menu.offsetHeight;
  let left = rect.left;
  if (left + menuW > window.innerWidth - 8) left = window.innerWidth - menuW - 8;
  left = Math.max(8, left);
  let top = rect.top - menuH - 8;
  if (top < 8) top = Math.min(rect.bottom + 8, window.innerHeight - menuH - 8);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.visibility = '';
}
document.getElementById('mpTrash').addEventListener('click', () => { closeSidebar(); openTrash(); });

document.addEventListener('click', e => {
  const wg = document.getElementById('widgetGallery');
  if (wg.classList.contains('open') && !wg.contains(e.target) && !document.getElementById('mpWidgets').contains(e.target))
    wg.classList.remove('open');
});
document.getElementById('wcBoard').querySelector('.widget-add-btn').addEventListener('click', () => {
  addBoard();
  document.getElementById('widgetGallery').classList.remove('open');
});

document.getElementById('wcNotes').querySelector('.widget-add-btn').addEventListener('click', () => {
  addNotes();
  document.getElementById('widgetGallery').classList.remove('open');
});
document.getElementById('wcPomodoro').querySelector('.widget-add-btn').addEventListener('click', () => {
  addPomodoro();
  document.getElementById('widgetGallery').classList.remove('open');
});

// ── Nav search toggle in widget gallery ──
function syncNavSearchCard() {
  const toggle = document.getElementById('navSearchToggle');
  if (!toggle) return;
  toggle.classList.toggle('on', !!S.navSearchEnabled);
}

document.getElementById('navSearchToggle').addEventListener('click', () => {
  S.navSearchEnabled = !S.navSearchEnabled;
  saveState();
  syncNavSearchCard();
  renderNavSearch();
  requestAnimationFrame(syncLayout);
});

document.getElementById('mpWidgets').addEventListener('click', syncNavSearchCard, { capture: true });

// ── Clock toggle in widget gallery ──
function syncClockCard() {
  const toggle = document.getElementById('clockToggle');
  if (!toggle) return;
  toggle.classList.toggle('on', !!S.clockEnabled);
}

document.getElementById('clockToggle').addEventListener('click', () => {
  S.clockEnabled = !S.clockEnabled;
  saveState();
  syncClockCard();
  renderClockWidget();
});

document.getElementById('mpWidgets').addEventListener('click', syncClockCard, { capture: true });

// ── Search ──
let _searchIdx = -1;

function openSearch() {
  document.getElementById('searchOverlay').classList.add('open');
  const inp = document.getElementById('searchInput');
  inp.value = '';
  document.getElementById('searchResults').innerHTML = '';
  _searchIdx = -1;
  setTimeout(() => inp.focus(), 30);
}
function closeSearch() {
  document.getElementById('searchOverlay').classList.remove('open');
}
function runSearch(q) {
  q = q.trim().toLowerCase();
  const box = document.getElementById('searchResults');
  box.innerHTML = '';
  _searchIdx = -1;
  if (!q) return;
  const hits = S.bookmarks.filter(bk =>
    bk.title.toLowerCase().includes(q) || bk.url.toLowerCase().includes(q)
  ).slice(0, 24);
  if (!hits.length) { box.innerHTML = `<div class="search-empty">${T('search.noResults')}</div>`; return; }
  hits.forEach((bk, i) => {
    const board = S.boards.find(b => b.id === bk.boardId);
    const el = document.createElement('div');
    el.className = 'search-result';
    const img = document.createElement('img');
    img.className = 'search-result-favicon';
    setFavicon(img, bk.url);
    const info = document.createElement('div');
    info.className = 'search-result-info';
    info.innerHTML = `<div class="search-result-title">${bk.title}</div><div class="search-result-meta">${board ? board.name : ''}</div>`;
    el.appendChild(img); el.appendChild(info);
    el.addEventListener('click', () => { window.open(bk.url, '_blank'); closeSearch(); });
    el.addEventListener('mouseover', () => setSearchIdx(i));
    box.appendChild(el);
  });
}
function setSearchIdx(i) {
  const items = document.querySelectorAll('.search-result');
  items.forEach(el => el.classList.remove('active'));
  _searchIdx = Math.max(0, Math.min(i, items.length - 1));
  if (items[_searchIdx]) { items[_searchIdx].classList.add('active'); items[_searchIdx].scrollIntoView({ block: 'nearest' }); }
}

document.getElementById('searchInput').addEventListener('input', e => runSearch(e.target.value));
document.getElementById('searchInput').addEventListener('keydown', e => {
  const items = document.querySelectorAll('.search-result');
  if (e.key === 'ArrowDown') { e.preventDefault(); setSearchIdx(_searchIdx + 1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); setSearchIdx(_searchIdx - 1); }
  else if (e.key === 'Enter' && items[_searchIdx]) items[_searchIdx].click();
  else if (e.key === 'Escape') closeSearch();
});
document.getElementById('searchOverlay').addEventListener('click', e => { if (e.target === e.currentTarget) closeSearch(); });
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openSearch(); }
});

// ── Trash ──
function openTrash() {
  renderTrash();
  document.getElementById('trashOverlay').classList.add('open');
}
function closeTrash() { showTrashConfirm(false); document.getElementById('trashOverlay').classList.remove('open'); }

function renderTrash() {
  const list = document.getElementById('trashList');
  list.innerHTML = '';
  const boards = S.trash.boards || [];
  const bks = (S.trash.bookmarks || []).filter(bk => !boards.find(b => b.id === bk.boardId));
  if (!boards.length && !bks.length) {
    list.innerHTML = `<div class="trash-empty-msg">${T('trash.isEmpty')}</div>`; return;
  }
  boards.forEach(board => {
    const el = document.createElement('div');
    el.className = 'trash-item';
    el.innerHTML = `<div class="trash-item-info"><div class="trash-item-title">📋 ${board.name}</div><div class="trash-item-meta">${T('trash.boardMeta', { n: S.trash.bookmarks.filter(bk => bk.boardId === board.id).length })}</div></div>`;
    const btn = document.createElement('button');
    btn.className = 'trash-item-restore';
    btn.textContent = T('trash.restore');
    btn.addEventListener('click', () => { restoreBoard(board.id); renderTrash(); });
    const del = document.createElement('button');
    del.className = 'trash-item-delete';
    del.textContent = '✕';
    del.title = T('tip.deletePermanently');
    del.addEventListener('click', () => { deleteBoardForever(board.id); renderTrash(); });
    el.appendChild(btn); el.appendChild(del);
    list.appendChild(el);
  });
  bks.forEach(bk => {
    const el = document.createElement('div');
    el.className = 'trash-item';
    const img = document.createElement('img');
    img.className = 'trash-item-icon';
    setFavicon(img, bk.url);
    const info = document.createElement('div');
    info.className = 'trash-item-info';
    info.innerHTML = `<div class="trash-item-title">${bk.title}</div><div class="trash-item-meta">${bk.url}</div>`;
    const btn = document.createElement('button');
    btn.className = 'trash-item-restore';
    btn.textContent = T('trash.restore');
    btn.addEventListener('click', () => { restoreBookmark(bk.id); renderTrash(); });
    const del = document.createElement('button');
    del.className = 'trash-item-delete';
    del.textContent = '✕';
    del.title = T('tip.deletePermanently');
    del.addEventListener('click', () => { deleteBookmarkForever(bk.id); renderTrash(); });
    el.appendChild(img); el.appendChild(info); el.appendChild(btn); el.appendChild(del);
    list.appendChild(el);
  });
}

function restoreBoard(boardId) {
  const board = S.trash.boards.find(b => b.id === boardId);
  if (!board) return;
  const { deletedAt, ...clean } = board;
  S.boards.push(clean);
  S.trash.bookmarks.filter(bk => bk.boardId === boardId).forEach(bk => {
    const { deletedAt: _, ...cleanBk } = bk;
    S.bookmarks.push(cleanBk);
  });
  S.trash.boards = S.trash.boards.filter(b => b.id !== boardId);
  S.trash.bookmarks = S.trash.bookmarks.filter(bk => bk.boardId !== boardId);
  saveState(); renderBoards();
}

function restoreBookmark(bkId) {
  const bk = S.trash.bookmarks.find(b => b.id === bkId);
  if (!bk) return;
  const { deletedAt, ...clean } = bk;
  S.bookmarks.push(clean);
  S.trash.bookmarks = S.trash.bookmarks.filter(b => b.id !== bkId);
  saveState(); renderBoards();
}

function deleteBoardForever(boardId) {
  S.trash.boards = S.trash.boards.filter(b => b.id !== boardId);
  S.trash.bookmarks = S.trash.bookmarks.filter(bk => bk.boardId !== boardId);
  saveState();
}

function deleteBookmarkForever(bkId) {
  S.trash.bookmarks = S.trash.bookmarks.filter(b => b.id !== bkId);
  saveState();
}

document.getElementById('trashCloseBtn').addEventListener('click', closeTrash);
document.getElementById('trashOverlay').addEventListener('click', e => { if (e.target === e.currentTarget) closeTrash(); });
function showTrashConfirm(show) {
  document.getElementById('trashConfirm').style.display = show ? 'flex' : 'none';
  document.getElementById('trashEmptyBtn').style.display = show ? 'none' : '';
}
document.getElementById('trashEmptyBtn').addEventListener('click', () => showTrashConfirm(true));
document.getElementById('trashConfirmCancel').addEventListener('click', () => showTrashConfirm(false));
document.getElementById('trashConfirmYes').addEventListener('click', () => {
  showTrashConfirm(false);
  S.trash = { boards: [], bookmarks: [] };
  saveState(); renderTrash();
});

// ── Import bookmarks ──
// Tour integration: set when the import modal is opened from the onboarding tour.
let _tourPausedForImport = false;
let _tourDidImport = false;

// folderId -> { name, parentName, bks } for the currently open modal's list,
// plus the set of folderIds the user has checked for bulk import.
let _importFolders = new Map();
let _importSelected = new Set();

function openImportModal() {
  const list = document.getElementById('importList');
  const selectAllRow = document.getElementById('importSelectAllRow');
  const footer = document.getElementById('importFooter');
  const selectAllChk = document.getElementById('importSelectAllChk');
  list.innerHTML = `<div class="import-msg">${T('import.loading')}</div>`;
  selectAllRow.style.display = 'none';
  footer.style.display = 'none';
  selectAllChk.checked = false;
  _importFolders = new Map();
  _importSelected = new Set();
  document.getElementById('importOverlay').classList.add('open');

  chrome.bookmarks.getTree().then(tree => {
    const folders = [];
    function traverse(nodes, parentName) {
      for (const node of nodes) {
        if (!node.url && node.children) {
          const bks = node.children.filter(n => n.url);
          if (bks.length > 0) folders.push({ id: node.id, name: node.title || T('import.untitled'), parentName, bks });
          traverse(node.children, node.title || '');
        }
      }
    }
    traverse(tree[0]?.children || [], '');

    list.innerHTML = '';
    if (!folders.length) {
      list.innerHTML = `<div class="import-msg">${T('import.noFolders')}</div>`;
      return;
    }

    folders.forEach(folder => _importFolders.set(folder.id, folder));

    folders.forEach(folder => {
      const el = document.createElement('div');
      el.className = 'import-item';
      const meta = (folder.parentName ? folder.parentName + ' · ' : '') + T('import.bookmarksMeta', { n: folder.bks.length });

      const chkLabel = document.createElement('label');
      chkLabel.className = 'import-item-chk';
      const chk = document.createElement('input');
      chk.type = 'checkbox';
      chk.dataset.folderId = folder.id;
      chk.addEventListener('change', () => {
        if (chk.checked) _importSelected.add(folder.id); else _importSelected.delete(folder.id);
        updateImportSelectionUI();
      });
      chkLabel.appendChild(chk);
      el.appendChild(chkLabel);

      const info = document.createElement('div');
      info.className = 'import-item-info';
      info.innerHTML = `
          <div class="import-item-name">${folder.name}</div>
          <div class="import-item-meta">${meta}</div>`;
      // Clicking anywhere on the row (outside the quick-import button) toggles the checkbox.
      info.addEventListener('click', () => { chk.checked = !chk.checked; chk.dispatchEvent(new Event('change')); });
      el.appendChild(info);

      const btn = document.createElement('button');
      btn.className = 'import-item-btn';
      btn.textContent = T('import.action');
      btn.title = T('import.actionSingle');
      btn.addEventListener('click', e => {
        e.stopPropagation();
        importBookmarkFolder(folder.name, folder.bks, folder.id);
        closeImportModal();
      });
      el.appendChild(btn);
      list.appendChild(el);
    });

    selectAllRow.style.display = '';
    footer.style.display = '';
    updateImportSelectionUI();
  }).catch(err => {
    list.innerHTML = `<div class="import-msg">${T('import.failed')}</div>`;
    console.error('Bookmarks API error:', err);
  });
}

function updateImportSelectionUI() {
  const total = _importFolders.size;
  const n = _importSelected.size;
  const selectAllChk = document.getElementById('importSelectAllChk');
  const countEl = document.getElementById('importSelectedCount');
  const bulkBtn = document.getElementById('importBulkBtn');
  selectAllChk.checked = total > 0 && n === total;
  selectAllChk.indeterminate = n > 0 && n < total;
  countEl.textContent = n > 0 ? T('import.selectedCount', { n }) : '';
  bulkBtn.disabled = n === 0;
  bulkBtn.textContent = n > 0 ? T('import.importSelectedN', { n }) : T('import.importSelected');
  // Keep row checkboxes visually in sync (e.g. after "select all").
  document.querySelectorAll('#importList .import-item-chk input').forEach(inp => {
    inp.checked = _importSelected.has(inp.dataset.folderId);
  });
}

document.getElementById('importSelectAllChk').addEventListener('change', e => {
  if (e.target.checked) {
    _importSelected = new Set(_importFolders.keys());
  } else {
    _importSelected.clear();
  }
  updateImportSelectionUI();
});

document.getElementById('importBulkBtn').addEventListener('click', () => {
  const folders = [..._importSelected].map(id => _importFolders.get(id)).filter(Boolean);
  folders.forEach(folder => importBookmarkFolder(folder.name, folder.bks, folder.id));
  closeImportModal();
});

function closeImportModal() {
  document.getElementById('importOverlay').classList.remove('open');
  if (_tourPausedForImport) _resumeTourAfterImport();
}

function importBookmarkFolder(name, bks, folderId) {
  if (!S.bookmarks) S.bookmarks = [];
  const { numCols } = getLayoutParams();
  const pageBoards = S.boards.filter(b => b.pageId === S.activePage);

  // Pick first column where at least a board header (~60px) would still be on screen
  const availH = window.innerHeight - 50; // minus topbar
  const colEls = document.querySelectorAll('#boardsArea .board-column');
  let col = numCols - 1; // fallback: last column
  for (let c = 0; c < numCols; c++) {
    const colH = c < colEls.length ? colEls[c].getBoundingClientRect().height : 0;
    if (colH + 60 <= availH) { col = c; break; }
  }
  const row = pageBoards.filter(b => b.col === col).reduce((m, b) => Math.max(m, b.row), -1) + 1;
  // syncFolderId links this board to the Chrome folder it was imported from;
  // syncEnabled is on by default so changes flow both ways (see the sync
  // section below) until the user's Chrome folder or this board is deleted.
  const board = { id: genId(), pageId: S.activePage, name, col, row, syncFolderId: folderId || null, syncEnabled: !!folderId };
  S.boards.push(board);
  bks.forEach((bk, i) => {
    let title = bk.title || bk.url;
    try { if (!bk.title) title = new URL(bk.url).hostname.replace('www.', ''); } catch {}
    S.bookmarks.push({ id: genId(), boardId: board.id, url: bk.url, title, order: i, chromeId: bk.id });
  });
  if (_tourPausedForImport) _tourDidImport = true;
  saveState();
  renderBoards();
  // Scroll to the newly created board so user can see it
  requestAnimationFrame(() => {
    const el = document.querySelector(`.board[data-id="${board.id}"]`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
  });
}

document.getElementById('importCloseBtn').addEventListener('click', closeImportModal);
document.getElementById('importOverlay').addEventListener('click', e => { if (e.target === e.currentTarget) closeImportModal(); });


let _resizeTimer;
window.addEventListener('resize', () => { clearTimeout(_resizeTimer); _resizeTimer = setTimeout(() => { renderBoards(); syncLayout(); }, 100); });

// When returning to the tab, immediately correct all running timer displays
document.addEventListener('visibilitychange', () => {
  if (document.hidden) return;
  Object.entries(_pomodoroState).forEach(([boardId, ps]) => {
    if (!ps.running || ps.startedAt == null) return;
    const elapsed = Math.floor((Date.now() - ps.startedAt) / 1000);
    ps.timeLeft = Math.max(0, ps.startedTimeLeft - elapsed);
    const t = document.querySelector(`.board[data-id="${boardId}"] .pom-timer`);
    if (t) t.textContent = pomFmt(ps.timeLeft);
    if (ps.timeLeft <= 0) {
      // Phase completed while away — re-render to handle transition
      renderBoards();
    }
  });
  updateFocusStats();
});

// ── Bookmark folder sync (two-way) ──
// A board created via Import carries board.syncFolderId (the Chrome
// bookmarks folder id it came from) and board.syncEnabled = true. While
// synced:
//   • Chrome-side changes to that folder (add / rename / edit URL / remove
//     a bookmark) push into the board.
//   • Board-side changes (add / edit / delete / reorder a link) push back
//     into that Chrome folder.
//   • Deleting a synced board deletes the Chrome folder too; deleting the
//     Chrome folder unlinks (and empties) the board's sync.
// Each synced bookmark carries a `chromeId` linking it to its Chrome node.
// The live listeners below only run while a new-tab page is open (this is
// an extension page with bookmarks access, not a background relay) — a
// reconciliation pass on init() catches up on anything that happened while
// every new-tab page was closed.
const _syncEcho = new Set(); // chromeIds our own writes just touched — ignore the next matching event for them
function _echoOnce(id) { _syncEcho.add(id); setTimeout(() => _syncEcho.delete(id), 1500); }

function syncedBoardByFolder(folderId) {
  return S.boards.find(b => b.syncFolderId === folderId && b.syncEnabled);
}

// ── Board → Chrome ──
function syncPushCreate(board, bk) {
  if (!board?.syncFolderId) return;
  chrome.bookmarks.create({ parentId: board.syncFolderId, title: bk.title, url: bk.url, index: bk.order }, node => {
    if (chrome.runtime.lastError || !node) return;
    _echoOnce(node.id);
    bk.chromeId = node.id;
    saveState();
  });
}
function syncPushUpdate(board, bk) {
  if (!board?.syncFolderId || !bk.chromeId) return;
  _echoOnce(bk.chromeId);
  chrome.bookmarks.update(bk.chromeId, { title: bk.title, url: bk.url }, () => void chrome.runtime.lastError);
}
function syncPushRemove(board, bk) {
  if (!board?.syncFolderId || !bk.chromeId) return;
  _echoOnce(bk.chromeId);
  chrome.bookmarks.remove(bk.chromeId, () => void chrome.runtime.lastError);
}
function syncPushReorder(board) {
  if (!board?.syncFolderId) return;
  S.bookmarks.filter(b => b.boardId === board.id).sort((a, b) => a.order - b.order).forEach((bk, i) => {
    if (!bk.chromeId) return;
    _echoOnce(bk.chromeId);
    chrome.bookmarks.move(bk.chromeId, { parentId: board.syncFolderId, index: i }, () => void chrome.runtime.lastError);
  });
}
function syncRemoveFolder(board) {
  if (!board?.syncFolderId) return;
  _echoOnce(board.syncFolderId);
  chrome.bookmarks.removeTree(board.syncFolderId, () => void chrome.runtime.lastError);
}
function syncRenameFolder(board) {
  if (!board?.syncFolderId) return;
  _echoOnce(board.syncFolderId);
  chrome.bookmarks.update(board.syncFolderId, { title: board.name }, () => void chrome.runtime.lastError);
}

// ── Chrome → Board (live, while this new-tab page is open) ──
chrome.bookmarks.onCreated.addListener((id, node) => {
  if (_syncEcho.has(id)) { _syncEcho.delete(id); return; }
  if (!node.url) return; // a folder was created — ignore
  const board = syncedBoardByFolder(node.parentId);
  if (!board || S.bookmarks.some(b => b.chromeId === id)) return;
  const count = S.bookmarks.filter(b => b.boardId === board.id).length;
  S.bookmarks.push({ id: genId(), boardId: board.id, url: node.url, title: node.title || node.url, order: node.index != null ? node.index : count, chromeId: id });
  saveState(); renderBoards();
});

chrome.bookmarks.onChanged.addListener((id, changeInfo) => {
  if (_syncEcho.has(id)) { _syncEcho.delete(id); return; }
  const bk = S.bookmarks.find(b => b.chromeId === id);
  if (!bk) return;
  const board = S.boards.find(b => b.id === bk.boardId);
  if (!board?.syncEnabled) return;
  if (changeInfo.title !== undefined) bk.title = changeInfo.title;
  if (changeInfo.url !== undefined) bk.url = changeInfo.url;
  saveState(); renderBoards();
});

chrome.bookmarks.onRemoved.addListener((id, removeInfo) => {
  if (_syncEcho.has(id)) { _syncEcho.delete(id); return; }
  // Whole synced folder deleted from Chrome — unlink sync, board itself stays.
  const folderBoard = S.boards.find(b => b.syncFolderId === id);
  if (folderBoard) { folderBoard.syncFolderId = null; folderBoard.syncEnabled = false; saveState(); renderBoards(); return; }
  const bk = S.bookmarks.find(b => b.chromeId === id);
  if (!bk) return;
  const board = S.boards.find(b => b.id === bk.boardId);
  if (!board?.syncEnabled) return;
  S.bookmarks = S.bookmarks.filter(b => b.id !== bk.id);
  saveState(); renderBoards();
});

chrome.bookmarks.onMoved.addListener((id, moveInfo) => {
  if (_syncEcho.has(id)) { _syncEcho.delete(id); return; }
  const bk = S.bookmarks.find(b => b.chromeId === id);
  const fromBoard = bk ? S.boards.find(b => b.id === bk.boardId) : null;
  const toBoard = syncedBoardByFolder(moveInfo.parentId);
  if (bk && fromBoard?.syncEnabled && !toBoard) {
    // Moved out of the synced folder — drop it from the board.
    S.bookmarks = S.bookmarks.filter(b => b.id !== bk.id);
    saveState(); renderBoards();
  } else if (bk && toBoard && bk.boardId !== toBoard.id) {
    bk.boardId = toBoard.id;
    saveState(); renderBoards();
  } else if (!bk && toBoard) {
    // Moved into a synced folder from somewhere else — pull it in.
    chrome.bookmarks.get(id).then(nodes => {
      const node = nodes && nodes[0];
      if (!node || !node.url) return;
      const count = S.bookmarks.filter(b => b.boardId === toBoard.id).length;
      S.bookmarks.push({ id: genId(), boardId: toBoard.id, url: node.url, title: node.title || node.url, order: count, chromeId: id });
      saveState(); renderBoards();
    }).catch(() => {});
  }
});

// Catches up on anything that changed in a synced folder while no new-tab
// page was open. Runs once at startup, before the first render.
async function reconcileSyncedFolders() {
  const synced = S.boards.filter(b => b.syncFolderId && b.syncEnabled);
  if (!synced.length) return;
  await Promise.all(synced.map(board =>
    chrome.bookmarks.getChildren(board.syncFolderId).then(children => {
      const chromeLeaves = children.filter(n => n.url);
      const chromeIds = new Set(chromeLeaves.map(n => n.id));

      // Chrome no longer has it — drop it from the board too.
      S.bookmarks.filter(b => b.boardId === board.id).forEach(bk => {
        if (bk.chromeId && !chromeIds.has(bk.chromeId)) {
          S.bookmarks = S.bookmarks.filter(b => b.id !== bk.id);
        }
      });

      // Chrome has something new — pull it in.
      const trackedChromeIds = new Set(S.bookmarks.filter(b => b.boardId === board.id).map(b => b.chromeId).filter(Boolean));
      chromeLeaves.forEach(node => {
        if (!trackedChromeIds.has(node.id)) {
          const count = S.bookmarks.filter(b => b.boardId === board.id).length;
          S.bookmarks.push({ id: genId(), boardId: board.id, url: node.url, title: node.title || node.url, order: node.index != null ? node.index : count, chromeId: node.id });
        }
      });

      // Board has links that never made it to Chrome (added while every
      // new-tab page was closed) — push them now.
      S.bookmarks.filter(b => b.boardId === board.id && !b.chromeId).forEach(bk => syncPushCreate(board, bk));
    }).catch(() => {
      // The folder itself is gone.
      board.syncFolderId = null; board.syncEnabled = false;
    })
  ));
  saveState();
}

// ── Theme utils ──
function hexToRgb(hex) {
  hex = hex.replace('#','');
  if (hex.length === 3) hex = hex.split('').map(c => c+c).join('');
  const n = parseInt(hex, 16);
  return { r:(n>>16)&255, g:(n>>8)&255, b:n&255 };
}
function colorBrightness(r, g, b) { return (r*299 + g*587 + b*114) / 1000; }

function applyThemeStyle(ts) {
  const root = document.documentElement;
  const {r,g,b} = hexToRgb(ts.boardColorHex||'#ffffff');
  root.style.setProperty('--board-rgb', `${r},${g},${b}`);
  root.style.setProperty('--board-alpha', ((ts.boardOpacity ?? 5) / 100).toFixed(3));
  root.style.setProperty('--board-blur', (ts.boardBlur ?? 12) + 'px');
  const borderAlpha = Math.min(0.35, ((ts.boardOpacity ?? 5) / 100) * 3).toFixed(3);
  root.style.setProperty('--board-border', `rgba(${r},${g},${b},${borderAlpha})`);
  const {r:ar,g:ag,b:ab} = hexToRgb(ts.accentHex||'#ffffff');
  root.style.setProperty('--accent-color', ts.accentHex||'#ffffff');
  root.style.setProperty('--accent-tab-bg', `rgba(${ar},${ag},${ab},0.8)`);
  root.style.setProperty('--accent-tab-border', `rgba(${ar},${ag},${ab},0.95)`);
  root.style.setProperty('--accent-tab-text', colorBrightness(ar,ag,ab) > 160 ? 'rgba(0,0,0,0.85)' : '#fff');

  // Board text color: blend board color with actual bg brightness (light/dark theme)
  const alpha = (ts.boardOpacity ?? 5) / 100;
  const hoverAlpha = Math.min(0.28, alpha + 0.05).toFixed(3);
  root.style.setProperty('--board-alpha-hover', hoverAlpha);
  const bgBrightness = ts.isDark === false ? 230 : 60;
  const effectiveBrightness = colorBrightness(r, g, b) * alpha + bgBrightness * (1 - alpha);
  const boardIsLight = effectiveBrightness > 128;
  if (boardIsLight) {
    root.style.setProperty('--board-text', 'rgba(0,0,0,0.85)');
    root.style.setProperty('--board-text-secondary', 'rgba(0,0,0,0.65)');
    root.style.setProperty('--board-text-dim', 'rgba(0,0,0,0.3)');
    root.style.setProperty('--board-text-hover', 'rgba(0,0,0,1)');
    root.style.setProperty('--board-hover-bg', 'rgba(0,0,0,0.07)');
  } else {
    root.style.setProperty('--board-text', 'rgba(255,255,255,0.9)');
    root.style.setProperty('--board-text-secondary', 'rgba(255,255,255,0.65)');
    root.style.setProperty('--board-text-dim', 'rgba(255,255,255,0.28)');
    root.style.setProperty('--board-text-hover', '#fff');
    root.style.setProperty('--board-hover-bg', 'rgba(255,255,255,0.07)');
  }

  // Global board text typography (size scale + weight), applied to all boards via
  // CSS variables — see .link-item / .link-title / .board-title / .link-desc.
  root.style.setProperty('--board-text-scale', ts.textScale || 1);
  root.style.setProperty('--link-weight', ts.textBold ? '600' : '400');

  document.body.classList.toggle('theme-light', ts.isDark === false);
}

// ── Custom wallpaper ──
// Supports a still image (data URL, stored/synced via Firestore) or a
// looping video (stored locally on this device only — free, no Firebase
// Storage / Blaze plan required. Doesn't cross-sync automatically; set it
// on each device separately if you want it on both).
function applyWallpaper() {
  let videoEl = document.getElementById('wallpaperVideo');
  if (S.wallpaperType === 'video' && _localWallpaperVideo) {
    document.body.style.backgroundImage = '';
    document.body.style.backgroundSize = '';
    document.body.style.backgroundPosition = '';
    document.body.style.backgroundRepeat = '';
    document.body.style.backgroundAttachment = '';
    if (!videoEl) {
      videoEl = document.createElement('video');
      videoEl.id = 'wallpaperVideo';
      videoEl.autoplay = true;
      videoEl.loop = true;
      videoEl.muted = true;
      videoEl.playsInline = true;
      videoEl.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;object-fit:cover;z-index:-1;';
      document.body.prepend(videoEl);
    }
    if (videoEl.getAttribute('src') !== _localWallpaperVideo) videoEl.src = _localWallpaperVideo;
    videoEl.play().catch(() => {});
  } else {
    if (videoEl) videoEl.remove();
    if (S.wallpaperType === 'image' && S.customWallpaper) {
      document.body.style.backgroundImage = `url("${S.customWallpaper}")`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundRepeat = 'no-repeat';
      document.body.style.backgroundAttachment = 'fixed';
    } else {
      document.body.style.backgroundImage = '';
      document.body.style.backgroundSize = '';
      document.body.style.backgroundPosition = '';
      document.body.style.backgroundRepeat = '';
      document.body.style.backgroundAttachment = '';
    }
  }
}

function setWallpaperFromFile(file) {
  if (!file || !/^image\//.test(file.type)) return;
  const reader = new FileReader();
  reader.onload = () => {
    _localWallpaperVideo = null;
    chrome.storage.local.remove('wallpaperVideoData');
    S.wallpaperType = 'image';
    S.customWallpaper = reader.result;
    applyWallpaper();
    saveState();
  };
  reader.readAsDataURL(file);
}

async function setWallpaperFromVideoFile(file) {
  if (!file || !/^video\/(mp4|webm)/.test(file.type)) { alert('Please choose an MP4 or WebM video.'); return; }
  if (file.size > 150 * 1024 * 1024) { alert('Video is too large — please use a file under 150MB.'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    _localWallpaperVideo = reader.result;
    chrome.storage.local.set({ wallpaperVideoData: reader.result });
    S.customWallpaper = null;
    S.wallpaperType = 'video';
    applyWallpaper();
    saveState();
  };
  reader.onerror = () => alert('Could not read that video file — please try again.');
  reader.readAsDataURL(file);
}

function clearWallpaper() {
  _localWallpaperVideo = null;
  chrome.storage.local.remove('wallpaperVideoData');
  S.customWallpaper = null;
  S.wallpaperType = null;
  applyWallpaper();
  saveState();
}

function exportBookmarks() {
  const data = {
    exportedAt: new Date().toISOString(),
    pages: S.pages,
    boards: S.boards,
    bookmarks: S.bookmarks.map(({ isDemo, ...bk }) => bk)
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'blackcodex-bookmarks-export.json';
  a.click();
  URL.revokeObjectURL(a.href);
}

// ── Onboarding ──
function checkOnboarding() {
  if (!localStorage.getItem('mz-onboard-done')) showOnboarding();
}

function showOnboarding() {
  document.getElementById('onboardOverlay').style.display = '';
}

document.getElementById('onboardStartBtn').addEventListener('click', () => {
  localStorage.setItem('mz-onboard-done', '1');
  document.getElementById('onboardOverlay').style.display = 'none';
  setTimeout(() => startTour(), 300);
});

// ── Settings ──
function _settingsOutsideClick(e) {
  if (!_settingsOpen) return;
  const modal = document.querySelector('.settings-modal');
  if (modal && !modal.contains(e.target)) closeSettingsModal();
}

let _settingsInitStyle = null;
let _settingsOpen = false;

function openSettingsModal() {
  const overlay = document.getElementById('settingsOverlay');
  overlay.style.display = 'block';
  _settingsOpen = true;
  _settingsInitStyle = JSON.parse(JSON.stringify(S.themeStyle || {}));
  try {
    renderSettingsBody();
    const body = document.getElementById('settingsBody');
    if (body) body.scrollTop = 0;
  } catch (err) {
    console.error('[BlackCodex] Settings render error:', err);
  }
  setTimeout(() => document.addEventListener('click', _settingsOutsideClick), 0);
}

function closeSettingsModal() {
  _settingsOpen = false;
  document.getElementById('settingsOverlay').style.display = 'none';
  document.removeEventListener('click', _settingsOutsideClick);
  const modal = document.querySelector('.settings-modal');
  if (modal) { modal.style.left = ''; modal.style.top = ''; modal.style.transform = ''; }
}

function renderSettingsBody() {
  const body = document.getElementById('settingsBody');
  if (!body) return;
  body.innerHTML = '';

  function section(title) {
    const s = document.createElement('div');
    s.className = 'st-section';
    const h = document.createElement('div');
    h.className = 'st-section-title';
    h.textContent = title;
    s.appendChild(h);
    return s;
  }
  function row(label, control) {
    const r = document.createElement('div');
    r.className = 'st-row';
    const l = document.createElement('span');
    l.className = 'st-row-label';
    l.textContent = label;
    r.appendChild(l);
    r.appendChild(control);
    return r;
  }
  function toggle(val, onChange) {
    const btn = document.createElement('button');
    btn.className = 'st-toggle' + (val ? ' on' : '');
    btn.innerHTML = '<span class="st-toggle-knob"></span>';
    btn.addEventListener('click', () => {
      const next = !btn.classList.contains('on');
      btn.classList.toggle('on', next);
      onChange(next);
    });
    return btn;
  }
  function btnGroup(options, current, onChange) {
    const wrap = document.createElement('div');
    wrap.className = 'st-btn-group';
    options.forEach(({ value, label: lbl }) => {
      const b = document.createElement('button');
      b.className = 'st-group-btn' + (current === value ? ' active' : '');
      b.textContent = lbl;
      b.addEventListener('click', () => {
        wrap.querySelectorAll('.st-group-btn').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        onChange(value);
      });
      wrap.appendChild(b);
    });
    return wrap;
  }

  // ── Sync ──
  if (window.Sync) {
    const syncSec = section('Sync');
    const user = Sync.currentUser();
    const status = document.createElement('div');
    status.className = 'st-row-label';
    status.style.cssText = 'margin-bottom:8px;opacity:.8;';
    status.textContent = user
      ? `Signed in as ${user.email} — syncing across devices.`
      : 'Not signed in — your setup only lives on this device.';
    syncSec.appendChild(status);

    const btn = document.createElement('button');
    btn.className = 'st-link';
    btn.textContent = user ? 'Sign out' : 'Sign in with Google';
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        if (user) {
          await Sync.signOut();
        } else {
          await Sync.signIn();
          const { resolvedState } = await Sync.init(S);
          if (resolvedState) { S = resolvedState; applyWallpaper(); renderAll(); }
        }
      } catch (err) {
        console.error('[Sync] auth action failed:', err);
        status.textContent = 'Something went wrong signing in — try again.';
      }
      renderSettingsBody();
    });
    syncSec.appendChild(btn);
    body.appendChild(syncSec);
  }

  // ── Data ──
  const accSec = section(T('st.data'));
  const dlBtn = document.createElement('button');
  dlBtn.className = 'st-link';
  dlBtn.textContent = T('st.download');
  dlBtn.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(S, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'newtab-data.json';
    a.click();
    URL.revokeObjectURL(a.href);
  });
  accSec.appendChild(dlBtn);
  body.appendChild(accSec);

  // ── Appearance ──
  const appSec = section(T('st.appearance'));
  const ts = S.themeStyle;

  function stColorField(label, currentHex, onChange) {
    const wrap = document.createElement('div');
    wrap.className = 'st-color-field';
    const l = document.createElement('span'); l.className = 'st-row-label'; l.textContent = label;
    const lbl = document.createElement('label'); lbl.style.cssText = 'display:block;cursor:pointer;position:relative;margin-top:6px;';
    const swatch = document.createElement('div'); swatch.className = 'st-color-swatch';
    swatch.style.background = currentHex;
    const picker = document.createElement('input');
    picker.type = 'color'; picker.value = currentHex;
    picker.style.cssText = 'position:absolute;opacity:0;width:0;height:0;';
    const onInput = () => { swatch.style.background = picker.value; onChange(picker.value); };
    picker.addEventListener('input', onInput); picker.addEventListener('change', onInput);
    lbl.appendChild(swatch); lbl.appendChild(picker);
    wrap.appendChild(l); wrap.appendChild(lbl);
    return wrap;
  }

  function stSliderField(label, min, max, step, current, unit, onChange) {
    const wrap = document.createElement('div');
    wrap.className = 'st-slider-field';
    const top = document.createElement('div');
    top.className = 'st-color-field-top';
    const l = document.createElement('span'); l.className = 'st-row-label'; l.textContent = label;
    const valSpan = document.createElement('span'); valSpan.className = 'se-hex-val'; valSpan.textContent = current + unit;
    top.appendChild(l); top.appendChild(valSpan);
    const slider = document.createElement('input');
    slider.type = 'range'; slider.className = 'se-slider st-slider';
    slider.min = min; slider.max = max; slider.step = step; slider.value = current;
    const updateFill = () => {
      const pct = (slider.value - min) / (max - min) * 100;
      slider.style.background = `linear-gradient(to right, var(--accent-color,#fff) ${pct}%, rgba(255,255,255,0.12) ${pct}%)`;
    };
    updateFill();
    slider.addEventListener('input', () => { valSpan.textContent = slider.value + unit; updateFill(); onChange(+slider.value); });
    wrap.appendChild(top); wrap.appendChild(slider);
    return wrap;
  }

  const applyAndSave = () => {
    applyThemeStyle(S.themeStyle);
    saveState();
  };

  const colorPair = document.createElement('div');
  colorPair.className = 'st-color-pair';
  colorPair.appendChild(stColorField(T('st.primaryColor'), ts.accentHex || '#ffffff',
    v => { S.themeStyle.accentHex = v; applyAndSave(); }));
  colorPair.appendChild(stColorField(T('st.boardColor'), ts.boardColorHex || '#ffffff',
    v => { S.themeStyle.boardColorHex = v; applyAndSave(); }));
  appSec.appendChild(colorPair);
  appSec.appendChild(stSliderField(T('st.opacity'), 0, 100, 1, ts.boardOpacity ?? 5, '%',
    v => { S.themeStyle.boardOpacity = v; applyAndSave(); }));
  appSec.appendChild(stSliderField(T('st.blur'), 0, 40, 1, ts.boardBlur ?? 12, 'px',
    v => { S.themeStyle.boardBlur = v; applyAndSave(); }));

  // Кнопки Cancel / Reset
  const styleBtnRow = document.createElement('div');
  styleBtnRow.style.cssText = 'display:flex;gap:8px;margin-top:4px;';
  const cancelStyleBtn = document.createElement('button');
  cancelStyleBtn.className = 'st-btn';
  cancelStyleBtn.textContent = T('common.cancel');
  cancelStyleBtn.addEventListener('click', e => {
    e.stopPropagation();
    if (_settingsInitStyle) { S.themeStyle = JSON.parse(JSON.stringify(_settingsInitStyle)); applyThemeStyle(S.themeStyle); saveState(); renderSettingsBody(); }
  });
  const resetStyleBtn = document.createElement('button');
  resetStyleBtn.className = 'st-btn';
  resetStyleBtn.textContent = T('common.reset');
  resetStyleBtn.addEventListener('click', e => {
    e.stopPropagation();
    S.themeStyle = { ...S.themeStyle, boardColorHex: '#ffffff', boardOpacity: 5, boardBlur: 12, accentHex: '#ffffff' };
    applyThemeStyle(S.themeStyle); saveState(); renderSettingsBody();
  });
  styleBtnRow.appendChild(cancelStyleBtn); styleBtnRow.appendChild(resetStyleBtn);
  appSec.appendChild(styleBtnRow);

  body.appendChild(appSec);

  // ── Board text ──
  const textSec = section(T('st.boardText'));
  textSec.appendChild(row(T('st.size'), btnGroup(
    [{ value: 0.9, label: 'S' }, { value: 1, label: 'M' }, { value: 1.15, label: 'L' }],
    ts.textScale ?? 1, v => { S.themeStyle.textScale = v; applyAndSave(); })));
  textSec.appendChild(row(T('st.weight'), btnGroup(
    [{ value: false, label: T('common.normal') }, { value: true, label: T('common.bold') }],
    ts.textBold ?? false, v => { S.themeStyle.textBold = v; applyAndSave(); })));
  body.appendChild(textSec);

  // ── General ──
  const genSec = section(T('st.general'));
  genSec.appendChild(row(T('st.openNewTab'), toggle(
    S.openInNewTab !== false,
    val => {
      S.openInNewTab = val;
      saveState();
      document.querySelectorAll('a.link-item').forEach(a => { a.target = val ? '_blank' : '_self'; });
    }
  )));

  // Hide extra bookmarks with count sub-option
  const hideRow = document.createElement('div');
  hideRow.className = 'st-row';
  const hideLabel = document.createElement('span');
  hideLabel.className = 'st-row-label';
  hideLabel.textContent = T('st.hideExtra');
  const hideRight = document.createElement('div');
  hideRight.style.cssText = 'display:flex;align-items:center;gap:8px;';
  const countSel = document.createElement('select');
  countSel.className = 'st-select';
  countSel.style.display = S.hideExtraBookmarks ? '' : 'none';
  [5, 10, 15, 20].forEach(n => {
    const opt = document.createElement('option');
    opt.value = n; opt.textContent = T('st.showN', { n });
    if (n === S.maxBookmarksShown) opt.selected = true;
    countSel.appendChild(opt);
  });
  countSel.addEventListener('change', () => {
    S.maxBookmarksShown = +countSel.value; saveState(); renderBoards();
  });
  const hideToggle = toggle(!!S.hideExtraBookmarks, val => {
    S.hideExtraBookmarks = val;
    countSel.style.display = val ? '' : 'none';
    saveState(); renderBoards();
  });
  hideRight.appendChild(countSel);
  hideRight.appendChild(hideToggle);
  hideRow.appendChild(hideLabel);
  hideRow.appendChild(hideRight);
  genSec.appendChild(hideRow);

  genSec.appendChild(row(T('st.showDescriptions'), toggle(
    !!S.showDescriptions,
    val => { S.showDescriptions = val; applyDescriptionsMode(); saveState(); }
  )));

  // ── Boards (layout) ──
  const boardsSec = section(T('st.boards'));

  // Max board columns (Auto = fit to window width). The <select> always shows
  // the EFFECTIVE column count (capped to what the window fits), never a chosen
  // number that can't physically be displayed.
  const colsSel = document.createElement('select');
  colsSel.className = 'st-select';
  const autoOpt = document.createElement('option');
  autoOpt.value = 'auto'; autoOpt.textContent = T('st.colsAuto');
  if (!S.maxBoardCols) autoOpt.selected = true;
  colsSel.appendChild(autoOpt);
  const effSel = S.maxBoardCols ? Math.min(S.maxBoardCols, getLayoutParams().autoCols) : null;
  [4, 5, 6, 7, 8, 9].forEach(n => {
    const opt = document.createElement('option');
    opt.value = n; opt.textContent = n;
    if (n === effSel) opt.selected = true;
    colsSel.appendChild(opt);
  });

  // One-off hint: shown only right after the user picks a count that can't fit
  // the current window. It is NOT restored when settings reopen — it's a passing
  // notice, not a persistent warning. Dismissable, and re-appears on a new pick.
  const colsHint = document.createElement('div');
  colsHint.className = 'st-field-hint';
  colsHint.style.display = 'none';
  const colsHintText = document.createElement('span');
  const colsHintClose = document.createElement('button');
  colsHintClose.className = 'st-field-hint-close';
  colsHintClose.textContent = '×';
  colsHintClose.setAttribute('aria-label', T('common.close'));
  colsHintClose.addEventListener('click', () => { colsHint.style.display = 'none'; });
  colsHint.appendChild(colsHintText);
  colsHint.appendChild(colsHintClose);
  // Re-snap the visible selection + hint to what the current width can fit.
  // showHint=true only right after an explicit column pick (a passing notice).
  const refreshColsDisplay = (showHint) => {
    const fits = getLayoutParams().autoCols;
    if (S.maxBoardCols) colsSel.value = String(Math.min(S.maxBoardCols, fits));
    if (showHint && S.maxBoardCols && S.maxBoardCols > fits) {
      colsHintText.textContent = T('st.colsHint', { n: fits });
      colsHint.style.display = '';
    } else {
      colsHint.style.display = 'none';
    }
  };
  colsSel.addEventListener('change', () => {
    S.maxBoardCols = colsSel.value === 'auto' ? null : +colsSel.value;
    saveState(); renderBoards();
    refreshColsDisplay(true);
    bwSync();   // the fit-cap changed → refresh the width slider's ceiling
  });
  boardsSec.appendChild(row(T('st.boardColumns'), colsSel));
  boardsSec.appendChild(colsHint);

  // Board width — independent of the column count. The slider's MAX is the widest
  // the current column count actually allows (the fit-cap), so the handle can't be
  // dragged past the point where boards stop growing and the px readout stays true.
  // S.boardWidth keeps the desired value, so fewer columns auto-widen the boards.
  const BW_MIN = 190, BW_AUTO_MAX = 380;
  const bwWrap = document.createElement('div');
  bwWrap.className = 'st-slider-field';
  const bwTop = document.createElement('div');
  bwTop.className = 'st-color-field-top';
  const bwLabel = document.createElement('span');
  bwLabel.className = 'st-row-label'; bwLabel.textContent = T('st.boardWidth');
  const bwVal = document.createElement('span');
  bwVal.className = 'se-hex-val';
  bwTop.appendChild(bwLabel); bwTop.appendChild(bwVal);
  const bwSlider = document.createElement('input');
  // step=1 so the max (an arbitrary fit-cap like 329px) is always reachable and
  // the handle travels the full track — a step of 10 would stop short of a
  // non-round max, leaving a visible gap at the right end.
  bwSlider.type = 'range'; bwSlider.className = 'se-slider st-slider';
  bwSlider.min = BW_MIN; bwSlider.step = 1;
  const bwFill = () => {
    const min = +bwSlider.min, max = +bwSlider.max;
    const pct = max > min ? (bwSlider.value - min) / (max - min) * 100 : 100;
    bwSlider.style.background = `linear-gradient(to right, var(--accent-color,#fff) ${pct}%, rgba(255,255,255,0.12) ${pct}%)`;
  };
  // Reconcile the slider with the current fit-cap (called on open + on column change).
  function bwSync() {
    const cap = S.maxBoardCols ? getLayoutParams().fitW : BW_AUTO_MAX;
    bwSlider.max = Math.max(BW_MIN, cap);
    const shown = Math.min(S.boardWidth || 260, +bwSlider.max);
    bwSlider.value = shown;
    bwVal.textContent = shown + 'px';
    bwFill();
  }
  bwSlider.addEventListener('input', () => {
    S.boardWidth = +bwSlider.value;
    bwVal.textContent = bwSlider.value + 'px';
    bwFill();
    saveState(); renderBoards(); refreshColsDisplay(false);
  });
  bwWrap.appendChild(bwTop); bwWrap.appendChild(bwSlider);
  bwSync();
  boardsSec.appendChild(bwWrap);

  body.appendChild(boardsSec);
  body.appendChild(genSec);

  // ── Quick Save ──
  const qsSec = section(T('st.quickSave'));
  const qsBoards = S.boards.filter(b => b.type !== 'pomodoro' && b.type !== 'notes' && b.type !== 'search');
  if (qsBoards.length) {
    const qsPages = S.pages || [];
    const curQsBoard = qsBoards.find(b => b.id === S.quickSaveBoard);
    let curQsPageId = curQsBoard?.pageId || qsPages[0]?.id;

    if (qsPages.length > 1) {
      const pageRow = document.createElement('div');
      pageRow.className = 'st-row';
      const pageLabel = document.createElement('span');
      pageLabel.className = 'st-row-label';
      pageLabel.textContent = T('st.saveToPage');
      const pageSel = document.createElement('select');
      pageSel.className = 'st-select';
      qsPages.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.id; opt.textContent = p.name;
        if (p.id === curQsPageId) opt.selected = true;
        pageSel.appendChild(opt);
      });
      pageRow.appendChild(pageLabel);
      pageRow.appendChild(pageSel);
      qsSec.appendChild(pageRow);

      const boardRow = document.createElement('div');
      boardRow.className = 'st-row';
      const boardLabel = document.createElement('span');
      boardLabel.className = 'st-row-label';
      boardLabel.textContent = T('st.saveToBoard');
      const boardSel = document.createElement('select');
      boardSel.className = 'st-select';

      function refreshQsBoards(pageId) {
        boardSel.innerHTML = '';
        qsBoards.filter(b => b.pageId === pageId).forEach(b => {
          const opt = document.createElement('option');
          opt.value = b.id; opt.textContent = b.name;
          if (b.id === S.quickSaveBoard) opt.selected = true;
          boardSel.appendChild(opt);
        });
        if (!S.quickSaveBoard || !boardSel.querySelector(`[value="${S.quickSaveBoard}"]`)) {
          S.quickSaveBoard = boardSel.value; saveState();
        }
      }
      refreshQsBoards(curQsPageId);
      pageSel.addEventListener('change', () => { refreshQsBoards(pageSel.value); });
      boardSel.addEventListener('change', () => { S.quickSaveBoard = boardSel.value; saveState(); });
      boardRow.appendChild(boardLabel);
      boardRow.appendChild(boardSel);
      qsSec.appendChild(boardRow);
    } else {
      const destRow = document.createElement('div');
      destRow.className = 'st-row';
      const destLabel = document.createElement('span');
      destLabel.className = 'st-row-label';
      destLabel.textContent = T('st.saveToBoard');
      const destSel = document.createElement('select');
      destSel.className = 'st-select';
      qsBoards.forEach(b => {
        const opt = document.createElement('option');
        opt.value = b.id; opt.textContent = b.name;
        if (b.id === S.quickSaveBoard || (!S.quickSaveBoard && b === qsBoards[0])) opt.selected = true;
        destSel.appendChild(opt);
      });
      if (!S.quickSaveBoard) { S.quickSaveBoard = qsBoards[0].id; saveState(); }
      destSel.addEventListener('change', () => { S.quickSaveBoard = destSel.value; saveState(); });
      destRow.appendChild(destLabel);
      destRow.appendChild(destSel);
      qsSec.appendChild(destRow);
    }
  }
  const popupRow = document.createElement('div');
  popupRow.className = 'st-row';
  popupRow.innerHTML = `<span class="st-row-label">${T('st.shortcut')}</span>`;
  const popupRight = document.createElement('div');
  popupRight.style.cssText = 'display:flex;align-items:center;gap:8px;';
  const popupKbd = document.createElement('kbd');
  popupKbd.className = 'st-kbd';
  popupKbd.textContent = '…';
  chrome.commands.getAll(cmds => {
    const cmd = cmds.find(c => c.name === '_execute_action');
    popupKbd.textContent = cmd?.shortcut || T('st.notSet');
  });
  const changeBtn = document.createElement('button');
  changeBtn.className = 'st-action-btn';
  changeBtn.style.cssText = 'width:auto;padding:4px 10px;margin:0;font-size:11px;';
  changeBtn.textContent = T('st.change');
  changeBtn.addEventListener('click', () => { chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }); });
  popupRight.appendChild(popupKbd);
  popupRight.appendChild(changeBtn);
  popupRow.appendChild(popupRight);
  qsSec.appendChild(popupRow);
  body.appendChild(qsSec);

  // ── Language ──
  const langSec = section(T('st.language'));
  langSec.appendChild(btnGroup(
    [{ value: 'auto', label: T('st.langAuto') }, { value: 'en', label: 'English' }, { value: 'ru', label: 'Русский' }],
    I18N.currentPref(),
    val => { if (val !== I18N.currentPref()) I18N.setLang(val); } // setLang persists + reloads
  ));
  body.appendChild(langSec);

  // ── Region ──
  const locSec = section(T('st.region'));
  const loc = S.locale;

  const locTopRow = document.createElement('div');
  locTopRow.className = 'st-row';
  const autoBtn = document.createElement('button');
  autoBtn.className = 'st-btn';
  autoBtn.textContent = T('st.autoDetect');
  autoBtn.addEventListener('click', e => {
    e.stopPropagation();
    S.locale = detectLocale();
    saveState();
    renderBoards();
    renderSettingsBody();
  });
  const advBtn = document.createElement('button');
  advBtn.className = 'st-btn';
  advBtn.textContent = T('st.advancedOpen');
  advBtn.style.marginLeft = 'auto';
  const locAdvanced = document.createElement('div');
  locAdvanced.style.display = 'none';
  advBtn.addEventListener('click', () => {
    const open = locAdvanced.style.display === '';
    locAdvanced.style.display = open ? 'none' : '';
    advBtn.textContent = open ? T('st.advancedOpen') : T('st.advancedClose');
  });
  const locBtnWrap = document.createElement('div');
  locBtnWrap.style.cssText = 'display:flex;gap:6px;width:100%';
  locBtnWrap.appendChild(autoBtn);
  locBtnWrap.appendChild(advBtn);
  locTopRow.appendChild(locBtnWrap);
  locSec.appendChild(locTopRow);

  locAdvanced.appendChild(row(T('st.timeFormat'), btnGroup(
    [{ value: '24h', label: '24h' }, { value: '12h', label: '12h AM/PM' }],
    loc.timeFormat || '24h',
    val => { loc.timeFormat = val; saveState(); tickClock(); }
  )));
  locAdvanced.appendChild(row(T('st.dateFormat'), btnGroup(
    [{ value: 'DMY', label: 'DD/MM/YY' }, { value: 'MDY', label: 'MM/DD/YY' }, { value: 'YMD', label: 'YY-MM-DD' }],
    loc.dateFormat || 'DMY',
    val => { loc.dateFormat = val; saveState(); tickClock(); }
  )));
  locAdvanced.appendChild(row(T('st.weekStart'), btnGroup(
    [{ value: 1, label: T('st.monday') }, { value: 0, label: T('st.sunday') }],
    loc.weekStart ?? 1,
    val => { loc.weekStart = val; saveState(); renderBoards(); }
  )));
  locSec.appendChild(locAdvanced);

  body.appendChild(locSec);

  // ── Sidebar ──
  const sbSec = section(T('st.sidebar'));
  sbSec.appendChild(row(T('st.alwaysShow'), toggle(
    !!S.sidebarAlwaysExpanded,
    val => { S.sidebarAlwaysExpanded = val; applySidebarMode(); saveState(); }
  )));
  body.appendChild(sbSec);

  // ── Support ──
  const supSec = section(T('st.support'));
  const versionRow = document.createElement('div');
  versionRow.className = 'st-row';
  const appVersion = chrome.runtime?.getManifest?.().version || '1.2.0';
  versionRow.innerHTML = `<span class="st-row-label">${T('st.version')}</span><span class="st-row-value">${appVersion}</span>`;
  supSec.appendChild(versionRow);
  body.appendChild(supSec);
}

function applySidebarMode() {
  document.getElementById('sidebar').classList.toggle('always-open', !!S.sidebarAlwaysExpanded);
}
function applyDescriptionsMode() {
  document.body.classList.toggle('show-descriptions', !!S.showDescriptions);
}

document.getElementById('settingsCloseBtn').addEventListener('click', closeSettingsModal);
document.getElementById('settingsSideBtn').addEventListener('click', e => {
  e.stopPropagation();
  if (_settingsOpen) {
    closeSettingsModal();
  } else {
    closeSidebar(); openSettingsModal();
  }
});

// ── Cloud sync reconciliation ──
// Applies an incoming remote state (from sign-in or a background poll) the
// same careful way we already handle cross-tab local updates: hold it if the
// user is mid-interaction, otherwise adopt it and persist + re-render.
function applyRemoteState(remote) {
  reconcileOrDefer(() => {
    S = remote;
    S._writer = _tabId;
    chrome.storage.local.set({ appState: S });
    applyWallpaper();
    renderAll();
  });
}
if (window.Sync) Sync.onRemoteUpdate(applyRemoteState);

// ── Init ──
async function init() {
  await loadState();
  if (window.Sync) {
    try {
      const { resolvedState } = await Sync.init(S);
      if (resolvedState) S = resolvedState;
    } catch (err) {
      console.error('[Sync] init failed:', err);
    }
  }
  await reconcileSyncedFolders();
  applyWallpaper();
  track('app_open', { total_boards: S.boards.length, total_bookmarks: S.bookmarks.length });
  trackDaily('daily_active');
  await loadFaviconCache();
  renderAll();
  updateFocusStats();
  applySidebarMode();
  applyDescriptionsMode();
  checkOnboarding();
  startClock();
  window.addEventListener('resize', updateNavLayout);
  syncNavSearchCard();
  syncClockCard();

}
init();



// ── Onboarding Tour ──
const TOUR_STEPS = [
  {
    target: '.boards-columns',
    title: T('tour.boardsTitle'),
    desc: T('tour.boardsDesc'),
    pos: 'center', noSpotlight: true,
    getBounds: () => {
      const boards = document.querySelectorAll('.board');
      if (!boards.length) return null;
      let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
      boards.forEach(b => { const r = b.getBoundingClientRect(); x1 = Math.min(x1, r.left); y1 = Math.min(y1, r.top); x2 = Math.max(x2, r.right); y2 = Math.max(y2, r.bottom); });
      return { left: x1, top: y1, right: x2, bottom: y2, width: x2 - x1, height: y2 - y1 };
    }
  },
  {
    target: '[data-tour="add-link"]',
    title: T('tour.addTitle'),
    desc: T('tour.addDesc'),
    pos: 'bottom', shape: 'circle'
  },
  {
    target: '[data-tour="add-page"]',
    title: T('tour.pagesTitle'),
    desc: T('tour.pagesDesc'),
    pos: 'bottom', shape: 'circle'
  },
  {
    target: '#menuSideBtn',
    title: T('tour.menuTitle'),
    desc: T('tour.menuDesc'),
    pos: 'left', shape: 'circle'
  },
  {
    target: '#settingsSideBtn',
    title: T('tour.settingsTitle'),
    desc: T('tour.settingsDesc'),
    pos: 'left', shape: 'circle'
  },
  {
    target: null,
    title: T('tour.saveTitle'),
    desc: T('tour.saveDesc'),
    pos: 'center'
  },
  {
    target: null,
    title: T('tour.bringTitle'),
    desc: T('tour.bringDesc'),
    pos: 'center', cta: 'import'
  },
  {
    target: null,
    title: T('tour.dragTitle'),
    desc: T('tour.dragDesc'),
    pos: 'center', demo: 'drag'
  },
  {
    target: null,
    title: T('tour.doneTitle'),
    desc: T('tour.doneDesc'),
    pos: 'center'
  }
];

let _tourStep = 0;
let _tourHighlighted = null;
// Active steps for the current run — may exclude the import/drag steps when
// the user has no Chrome bookmarks to import.
let _tourSteps = TOUR_STEPS;

function hasChromeBookmarks() {
  return new Promise(resolve => {
    if (!chrome?.bookmarks?.getTree) { resolve(false); return; }
    chrome.bookmarks.getTree(tree => {
      let found = false;
      (function walk(nodes) {
        for (const n of nodes || []) {
          if (found) return;
          if (n.url) { found = true; return; }
          if (n.children) walk(n.children);
        }
      })(tree?.[0]?.children || []);
      resolve(found);
    });
  });
}

function startTour() {
  if (localStorage.getItem('mz-tour-done')) return;
  track('tour_started');
  _tourStep = 0;
  // No bookmarks to import → drop only the import step, but keep the drag demo.
  hasChromeBookmarks().then(has => {
    _tourSteps = has ? TOUR_STEPS : TOUR_STEPS.filter(s => !s.cta);
    document.getElementById('tourOverlay').style.display = '';
    document.getElementById('tourTooltip').style.display = '';
    showTourStep(0);
  });
}

function _clearTourRects() {
  document.querySelectorAll('.tour-overlay-rect').forEach(d => d.remove());
}

function setTourOverlayMask(el, shape, customBounds) {
  const overlay = document.getElementById('tourOverlay');
  _clearTourRects();
  overlay.style.background = '';
  overlay.style.mask = overlay.style.webkitMask = '';

  if (!el) return;

  const r = customBounds || el.getBoundingClientRect();
  const W = window.innerWidth, H = window.innerHeight;

  if (shape === 'circle') {
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const radius = Math.max(r.width, r.height) / 2 + 18;
    overlay.style.background = `radial-gradient(circle ${radius}px at ${cx}px ${cy}px, transparent ${radius - 1}px, rgba(0,0,0,0.55) ${radius}px)`;
  } else {
    const pad = shape === 'large' ? 24 : 14;
    const x1 = Math.max(0, r.left - pad),   y1 = Math.max(0, r.top - pad);
    const x2 = Math.min(W, r.right + pad),  y2 = Math.min(H, r.bottom + pad);
    const dark = 'rgba(0,0,0,0.55)';
    [
      { t: 0,  l: 0,  w: W,      h: y1        },
      { t: y2, l: 0,  w: W,      h: H - y2    },
      { t: y1, l: 0,  w: x1,     h: y2 - y1   },
      { t: y1, l: x2, w: W - x2, h: y2 - y1   },
    ].forEach(({ t, l, w, h }) => {
      if (w <= 0 || h <= 0) return;
      const d = document.createElement('div');
      d.className = 'tour-overlay-rect';
      d.style.cssText = `position:fixed;z-index:800;pointer-events:none;background:${dark};top:${t}px;left:${l}px;width:${w}px;height:${h}px;`;
      document.body.appendChild(d);
    });
  }
}

function showTourStep(idx) {
  const step = _tourSteps[idx];
  track('tour_step', { index: idx });
  const el = step.target ? document.querySelector(step.target) : null;

  if (_tourHighlighted) {
    _tourHighlighted.classList.remove('tour-spotlight');
    _tourHighlighted.closest?.('.board')?.classList.remove('tour-board-reveal');
  }
  if (el) {
    el.classList.add('tour-spotlight');
    el.closest?.('.board')?.classList.add('tour-board-reveal');
    _tourHighlighted = el;
  } else { _tourHighlighted = null; }
  setTourOverlayMask(step.noSpotlight ? null : el, step.shape, step.getBounds?.());

  document.getElementById('tourStepLabel').textContent = T('tour.counter', { i: idx + 1, total: _tourSteps.length });
  document.getElementById('tourTitle').textContent = step.title;
  document.getElementById('tourDesc').textContent = step.desc;
  const nextBtn = document.getElementById('tourNextBtn');
  nextBtn.textContent = step.cta === 'import' ? T('tour.importBookmarks')
    : (idx === _tourSteps.length - 1 ? T('tour.done') : T('tour.next'));
  document.getElementById('tourLaterBtn').style.display = step.cta === 'import' ? '' : 'none';
  document.getElementById('tourBackBtn').style.display = (idx > 0 && step.cta !== 'import') ? '' : 'none';
  document.querySelector('.tour-footer').classList.toggle('cta', step.cta === 'import');

  // Self-contained drag illustration lives inside the tooltip (no dependency
  // on real board layout/scroll position).
  document.getElementById('tourDemo').style.display = step.demo === 'drag' ? '' : 'none';

  positionTourTooltip(el, step.pos);
}

function positionTourTooltip(el, pos) {
  const tooltip = document.getElementById('tourTooltip');
  if (!el || pos === 'center') {
    tooltip.style.top = '50%';
    tooltip.style.left = '50%';
    tooltip.style.transform = 'translate(-50%, -50%)';
    return;
  }
  const r = el.getBoundingClientRect();
  tooltip.style.transform = '';
  if (pos === 'right') {
    tooltip.style.top = Math.max(16, r.top + r.height / 2 - 80) + 'px';
    tooltip.style.left = (r.right + 16) + 'px';
  } else if (pos === 'left') {
    const rawTop = r.top + r.height / 2 - 80;
    tooltip.style.top = Math.min(Math.max(16, rawTop), window.innerHeight - 220) + 'px';
    tooltip.style.left = Math.max(16, r.left - 296) + 'px';
  } else if (pos === 'bottom') {
    tooltip.style.top = (r.bottom + 12) + 'px';
    tooltip.style.left = Math.min(r.left, window.innerWidth - 300) + 'px';
  }
}

function endTour(reason = 'skipped') {
  track(reason === 'completed' ? 'tour_completed' : 'tour_skipped', { step: _tourStep });
  localStorage.setItem('mz-tour-done', '1');
  document.getElementById('tourOverlay').style.display = 'none';
  document.getElementById('tourTooltip').style.display = 'none';
  document.getElementById('tourDemo').style.display = 'none';
  if (_tourHighlighted) {
    _tourHighlighted.classList.remove('tour-spotlight');
    _tourHighlighted.closest?.('.board')?.classList.remove('tour-board-reveal');
    _tourHighlighted = null;
  }
  setTourOverlayMask(null);
  _clearTourRects();
}

// Opens the import modal mid-tour, hiding the tour chrome until the modal closes.
function _tourOpenImport() {
  _tourPausedForImport = true;
  _tourDidImport = false;
  document.getElementById('tourOverlay').style.display = 'none';
  document.getElementById('tourTooltip').style.display = 'none';
  _clearTourRects();
  if (_tourHighlighted) {
    _tourHighlighted.classList.remove('tour-spotlight');
    _tourHighlighted.closest?.('.board')?.classList.remove('tour-board-reveal');
    _tourHighlighted = null;
  }
  openImportModal();
}

// Called from closeImportModal when the modal was opened by the tour.
function _resumeTourAfterImport() {
  _tourPausedForImport = false;
  document.getElementById('tourOverlay').style.display = '';
  document.getElementById('tourTooltip').style.display = '';
  if (_tourDidImport) {
    _tourDidImport = false;
    _tourStep++; // advance from the import step to the drag demo
  }
  showTourStep(_tourStep);
}

document.getElementById('tourNextBtn').addEventListener('click', () => {
  const step = _tourSteps[_tourStep];
  if (step?.cta === 'import') { _tourOpenImport(); return; }
  if (_tourStep < _tourSteps.length - 1) { _tourStep++; showTourStep(_tourStep); }
  else endTour('completed');
});
document.getElementById('tourLaterBtn').addEventListener('click', () => {
  // Declined import → skip only the import, still show the drag demo next.
  if (_tourStep < _tourSteps.length - 1) { _tourStep++; showTourStep(_tourStep); }
  else endTour('completed');
});
document.getElementById('tourBackBtn').addEventListener('click', () => {
  if (_tourStep > 0) { _tourStep--; showTourStep(_tourStep); }
});
document.getElementById('tourSkipBtn').addEventListener('click', () => endTour('skipped'));
